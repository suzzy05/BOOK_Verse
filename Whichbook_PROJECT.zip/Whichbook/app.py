import os
import logging
from flask import Flask, render_template, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Enable CORS
CORS(app)

# Configure the database
database_url = os.environ.get("DATABASE_URL", "sqlite:///whichbook.db")
# Ensure SQLite URLs start with sqlite:///
if database_url.startswith("sqlite://") and not database_url.startswith("sqlite:///"):
    database_url = database_url.replace("sqlite://", "sqlite:///")

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the database
db.init_app(app)

@app.route('/')
def index():
    """Render the main index page"""
    return render_template('index.html')
    
@app.route('/api/test')
def test():
    """Simple test endpoint"""
    return jsonify({"status": "ok", "message": "API is working"})

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    if request.path.startswith('/api/'):
        return jsonify({"error": "Resource not found"}), 404
    return render_template('index.html')

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    app.logger.error(f"Server error: {str(e)}")
    if request.path.startswith('/api/'):
        return jsonify({"error": "Internal server error"}), 500
    return render_template('index.html')

# Create all database tables
with app.app_context():
    import models
    from csv_loader import load_all_books
    
    db.create_all()
    
    # Load books from CSV files if the database is empty
    from models import Book
    if Book.query.count() == 0:
        app.logger.info("Loading books from CSV files...")
        load_all_books()
        app.logger.info("Books loaded successfully!")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
