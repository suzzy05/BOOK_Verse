from flask import jsonify, request, current_app
from data_manager import DataManager
from models import Book, Mood, Theme
import random

def register_routes(app):
    """Register API routes for the application"""
    data_manager = DataManager()
    
    @app.route('/api/books', methods=['GET'])
    def get_books():
        """Get books with optional filters"""
        try:
            # Extract query parameters
            page = int(request.args.get('page', 1))
            per_page = int(request.args.get('perPage', 20))
            
            # Extract mood filters
            mood_filters = {}
            for key, value in request.args.items():
                if key.startswith('mood_'):
                    try:
                        mood_id = key.replace('mood_', '')
                        mood_filters[mood_id] = int(value)
                    except ValueError:
                        pass
            
            # Extract theme filters
            theme_ids = []
            if 'theme' in request.args:
                # Handle both single theme and multiple themes
                themes = request.args.getlist('theme')
                theme_ids = [int(theme_id) for theme_id in themes if theme_id.isdigit()]
            
            # Get filtered books
            books, total = data_manager.get_books(
                page=page,
                per_page=per_page,
                mood_filters=mood_filters,
                theme_ids=theme_ids
            )
            
            # Convert books to dictionaries
            books_data = [book.to_dict() for book in books]
            
            return jsonify({
                'books': books_data,
                'page': page,
                'perPage': per_page,
                'total': total
            })
        except Exception as e:
            current_app.logger.error(f"Error in get_books: {str(e)}")
            return jsonify({'error': 'Failed to retrieve books'}), 500

    @app.route('/api/books/<int:book_id>', methods=['GET'])
    def get_book(book_id):
        """Get a single book by ID"""
        try:
            book = data_manager.get_book(book_id)
            if not book:
                return jsonify({'error': 'Book not found'}), 404
            
            return jsonify(book.to_dict())
        except Exception as e:
            current_app.logger.error(f"Error in get_book: {str(e)}")
            return jsonify({'error': 'Failed to retrieve book'}), 500

    @app.route('/api/books/search', methods=['GET'])
    def search_books():
        """Search books by query"""
        try:
            query = request.args.get('q', '')
            page = int(request.args.get('page', 1))
            per_page = int(request.args.get('perPage', 20))
            
            books, total = data_manager.search_books(query, page, per_page)
            
            books_data = [book.to_dict() for book in books]
            
            return jsonify({
                'books': books_data,
                'page': page,
                'perPage': per_page,
                'total': total,
                'query': query
            })
        except Exception as e:
            current_app.logger.error(f"Error in search_books: {str(e)}")
            return jsonify({'error': 'Failed to search books'}), 500

    @app.route('/api/books/random', methods=['GET'])
    def get_random_book():
        """Get a random book"""
        try:
            book = data_manager.get_random_book()
            if not book:
                return jsonify({'error': 'No books available'}), 404
            
            return jsonify(book.to_dict())
        except Exception as e:
            current_app.logger.error(f"Error in get_random_book: {str(e)}")
            return jsonify({'error': 'Failed to retrieve random book'}), 500

    @app.route('/api/books/<int:book_id>/similar', methods=['GET'])
    def get_similar_books(book_id):
        """Get books similar to the given book"""
        try:
            count = int(request.args.get('count', 4))
            
            similar_books = data_manager.get_similar_books(book_id, count)
            
            books_data = [book.to_dict() for book in similar_books]
            
            return jsonify(books_data)
        except Exception as e:
            current_app.logger.error(f"Error in get_similar_books: {str(e)}")
            return jsonify({'error': 'Failed to retrieve similar books'}), 500

    @app.route('/api/moods', methods=['GET'])
    def get_moods():
        """Get all available moods"""
        try:
            moods = data_manager.get_moods()
            
            moods_data = [mood.to_dict() for mood in moods]
            
            return jsonify(moods_data)
        except Exception as e:
            current_app.logger.error(f"Error in get_moods: {str(e)}")
            return jsonify({'error': 'Failed to retrieve moods'}), 500

    @app.route('/api/themes', methods=['GET'])
    def get_themes():
        """Get all available themes"""
        try:
            themes = data_manager.get_themes()
            
            themes_data = [theme.to_dict() for theme in themes]
            
            return jsonify(themes_data)
        except Exception as e:
            current_app.logger.error(f"Error in get_themes: {str(e)}")
            return jsonify({'error': 'Failed to retrieve themes'}), 500

    @app.route('/api/themes/categories', methods=['GET'])
    def get_theme_categories():
        """Get all theme categories"""
        try:
            categories = data_manager.get_theme_categories()
            
            return jsonify(categories)
        except Exception as e:
            current_app.logger.error(f"Error in get_theme_categories: {str(e)}")
            return jsonify({'error': 'Failed to retrieve theme categories'}), 500
