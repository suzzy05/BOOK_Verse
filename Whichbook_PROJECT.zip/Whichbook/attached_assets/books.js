/**
 * Books module for Whichbook
 * Handles book display and interactions
 */
const Books = {
    /**
     * Initialize the book functionality
     */
    init: function() {
        // No initialization needed for now
    },
    
    /**
     * Load featured books for the homepage
     */
    loadFeaturedBooks: async function() {
        try {
            const container = document.getElementById('featured-books');
            if (!container) return;
            
            // Clear current content and show loading indicator
            container.innerHTML = '<div class="text-center w-100"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get some books (no filters, just first page)
            const response = await API.getBooks({ page: 1, perPage: 4 });
            
            // Clear loading indicator
            container.innerHTML = '';
            
            // Render books
            response.books.forEach(book => {
                container.appendChild(this.createBookCard(book));
            });
        } catch (error) {
            console.error('Error loading featured books:', error);
            const container = document.getElementById('featured-books');
            if (container) {
                container.innerHTML = '<div class="alert alert-danger w-100">Error loading books. Please try again later.</div>';
            }
        }
    },
    
    /**
     * Create a book card element
     * @param {Object} book - Book data
     * @returns {HTMLElement} Book card element
     */
    createBookCard: function(book) {
        // Clone the template
        const template = document.getElementById('book-card-template');
        const bookCard = template.content.cloneNode(true);
        
        // Set book data
        const img = bookCard.querySelector('.book-cover-img');
        img.src = book.cover_image;
        img.alt = `${book.title} cover`;
        
        bookCard.querySelector('.book-title').textContent = book.title;
        bookCard.querySelector('.book-author').textContent = book.author;
        
        const viewBookLink = bookCard.querySelector('.view-book');
        viewBookLink.href = `/book/${book.id}`;
        viewBookLink.setAttribute('data-book-id', book.id);
        
        viewBookLink.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.hash = `#book/${book.id}`;
        });
        
        return bookCard.children[0]; // Return the actual element, not the document fragment
    },
    
    /**
     * Display book list based on filters
     * @param {Object} options - Filter options (moodFilters, themeIds, page)
     */
    displayBookList: async function(options = {}) {
        try {
            const container = document.getElementById('book-list');
            if (!container) return;
            
            // Set default values
            const page = options.page || 1;
            const perPage = options.perPage || 20;
            
            // Clear current content and show loading indicator
            container.innerHTML = '<div class="text-center w-100"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get filtered books
            const response = await API.getBooks({
                moodFilters: options.moodFilters,
                themeIds: options.themeIds,
                page: page,
                perPage: perPage
            });
            
            // Clear loading indicator
            container.innerHTML = '';
            
            // Update results description
            const resultsDescription = document.getElementById('results-description');
            if (resultsDescription) {
                resultsDescription.textContent = `Found ${response.total} book${response.total !== 1 ? 's' : ''}`;
            }
            
            // Handle no results
            if (response.books.length === 0) {
                container.innerHTML = '<div class="col-12 text-center"><div class="alert alert-info">No books found matching your criteria. Try adjusting your filters.</div></div>';
                return;
            }
            
            // Render books
            response.books.forEach(book => {
                container.appendChild(this.createBookCard(book));
            });
            
            // Create pagination
            this.createPagination(response, 'pagination-container', page, (newPage) => {
                options.page = newPage;
                this.displayBookList(options);
                window.scrollTo(0, 0);
            });
        } catch (error) {
            console.error('Error displaying book list:', error);
            const container = document.getElementById('book-list');
            if (container) {
                container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error loading books. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Display a single book's details
     * @param {string} bookId - ID of the book to display
     */
    displayBookDetail: async function(bookId) {
        try {
            const container = document.getElementById('app-container');
            if (!container) return;
            
            // Show loading indicator
            container.innerHTML = '<div class="container text-center mt-5 pt-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Fetch book data
            const book = await API.getBook(bookId);
            
            // Get similar books
            const similarBooks = await API.getSimilarBooks(bookId);
            
            // Clone template
            const template = document.getElementById('book-detail-template');
            const bookDetail = template.content.cloneNode(true);
            
            // Set basic book info
            bookDetail.querySelector('#book-cover').src = book.cover_image;
            bookDetail.querySelector('#book-cover').alt = `${book.title} cover`;
            bookDetail.querySelector('#book-title').textContent = book.title;
            bookDetail.querySelector('#book-author').textContent = book.author;
            bookDetail.querySelector('#book-year').textContent = book.publication_year;
            bookDetail.querySelector('#book-isbn').textContent = book.isbn;
            bookDetail.querySelector('#book-pages').textContent = book.pages;
            bookDetail.querySelector('#book-description').textContent = book.description;
            
            // Set mood ratings
            const moodRatingsContainer = bookDetail.querySelector('#book-mood-ratings');
            
            if (book.mood_ratings) {
                // Fetch all moods to get their labels
                const moods = await API.getMoods();
                const moodsMap = new Map(moods.map(mood => [mood.id, mood]));
                
                // Create a mood rating display for each mood
                for (const [moodId, rating] of Object.entries(book.mood_ratings)) {
                    const mood = moodsMap.get(moodId);
                    if (!mood) continue;
                    
                    const ratingElem = document.createElement('div');
                    ratingElem.className = 'mood-rating-display';
                    
                    // Determine which label to show based on rating
                    let ratingLabel = '';
                    if (rating < -50) {
                        ratingLabel = mood.min_label;
                    } else if (rating > 50) {
                        ratingLabel = mood.max_label;
                    } else {
                        ratingLabel = `${mood.min_label} ↔ ${mood.max_label}`;
                    }
                    
                    // Create the HTML
                    ratingElem.innerHTML = `
                        <div class="mood-rating-name">${mood.name}</div>
                        <div class="mood-rating-bar-container">
                            <div class="mood-rating-bar ${rating < 0 ? 'positive' : 'negative'}" 
                                 style="width: ${Math.abs(rating)}%;"></div>
                        </div>
                    `;
                    
                    moodRatingsContainer.appendChild(ratingElem);
                }
            } else {
                moodRatingsContainer.innerHTML = '<p>No mood ratings available for this book.</p>';
            }
            
            // Set themes
            const themesContainer = bookDetail.querySelector('#book-themes');
            
            if (book.themes && book.themes.length > 0) {
                // Fetch all themes to get their full info
                const themes = await API.getThemes();
                const themesMap = new Map(themes.map(theme => [theme.id, theme]));
                
                const themesDiv = document.createElement('div');
                book.themes.forEach(themeId => {
                    const theme = themesMap.get(themeId);
                    if (!theme) return;
                    
                    const themeTag = document.createElement('span');
                    themeTag.className = 'theme-tag';
                    themeTag.textContent = theme.name;
                    themeTag.addEventListener('click', () => {
                        window.location.hash = `#themes/?theme=${themeId}`;
                    });
                    
                    themesDiv.appendChild(themeTag);
                });
                
                themesContainer.appendChild(themesDiv);
            } else {
                themesContainer.innerHTML = '<p>No themes available for this book.</p>';
            }
            
            // Set excerpt if available
            const excerptContainer = bookDetail.querySelector('#book-excerpt-container');
            const excerptText = bookDetail.querySelector('#book-excerpt');
            
            if (book.excerpt) {
                excerptText.textContent = book.excerpt;
            } else {
                excerptContainer.style.display = 'none';
            }
            
            // Set similar books
            const similarBooksContainer = bookDetail.querySelector('#similar-books');
            
            if (similarBooks && similarBooks.length > 0) {
                similarBooks.forEach(similarBook => {
                    similarBooksContainer.appendChild(this.createBookCard(similarBook));
                });
            } else {
                bookDetail.querySelector('.similar-books-section').style.display = 'none';
            }
            
            // Replace content
            container.innerHTML = '';
            container.appendChild(bookDetail);
            
            // Scroll to top
            window.scrollTo(0, 0);
        } catch (error) {
            console.error('Error displaying book details:', error);
            const container = document.getElementById('app-container');
            if (container) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">Error loading book details. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Display search results
     * @param {string} query - Search query
     * @param {number} page - Page number
     */
    displaySearchResults: async function(query, page = 1) {
        try {
            const container = document.getElementById('app-container');
            if (!container) return;
            
            // Show loading indicator
            container.innerHTML = '<div class="container text-center mt-5 pt-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Fetch search results
            const perPage = 20;
            const response = await API.searchBooks(query, page, perPage);
            
            // Clone template
            const template = document.getElementById('search-results-template');
            const searchResults = template.content.cloneNode(true);
            
            // Set search query display
            const queryDisplay = searchResults.querySelector('#search-query-display');
            queryDisplay.textContent = `Search results for "${query}"`;
            
            // Get results container and populate it
            const resultsContainer = searchResults.querySelector('#search-results-list');
            
            if (response.books.length === 0) {
                resultsContainer.innerHTML = '<div class="col-12 text-center"><div class="alert alert-info">No books found matching your search. Try a different query.</div></div>';
            } else {
                response.books.forEach(book => {
                    resultsContainer.appendChild(this.createBookCard(book));
                });
            }
            
            // Create pagination
            this.createPagination(response, 'search-pagination-container', page, (newPage) => {
                window.location.hash = `#search/${query}/${newPage}`;
            });
            
            // Replace content
            container.innerHTML = '';
            container.appendChild(searchResults);
            
            // Scroll to top
            window.scrollTo(0, 0);
        } catch (error) {
            console.error('Error displaying search results:', error);
            const container = document.getElementById('app-container');
            if (container) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">Error searching for books. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Display a random book
     */
    displayRandomBook: async function() {
        try {
            const container = document.getElementById('app-container');
            if (!container) return;
            
            // Show loading indicator
            container.innerHTML = '<div class="container text-center mt-5 pt-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get all books (first page only) and select a random one
            const response = await API.getBooks({ page: 1, perPage: 50 });
            
            if (!response.books || response.books.length === 0) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">No books available to select randomly.</div></div>';
                return;
            }
            
            const randomIndex = Math.floor(Math.random() * response.books.length);
            const randomBook = response.books[randomIndex];
            
            // Clone template
            const template = document.getElementById('random-book-template');
            const randomBookView = template.content.cloneNode(true);
            
            // Set book data
            randomBookView.querySelector('#random-book-cover').src = randomBook.cover_image;
            randomBookView.querySelector('#random-book-title').textContent = randomBook.title;
            randomBookView.querySelector('#random-book-author').textContent = randomBook.author;
            randomBookView.querySelector('#random-book-description').textContent = randomBook.description;
            
            const bookLink = randomBookView.querySelector('#random-book-link');
            bookLink.href = `/book/${randomBook.id}`;
            bookLink.addEventListener('click', (e) => {
                e.preventDefault();
                window.location.hash = `#book/${randomBook.id}`;
            });
            
            // Add another random book button event
            randomBookView.querySelector('#another-random-book').addEventListener('click', () => {
                this.displayRandomBook();
            });
            
            // Replace content
            container.innerHTML = '';
            container.appendChild(randomBookView);
            
            // Scroll to top
            window.scrollTo(0, 0);
        } catch (error) {
            console.error('Error displaying random book:', error);
            const container = document.getElementById('app-container');
            if (container) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">Error loading a random book. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Create pagination controls
     * @param {Object} response - API response containing pagination info
     * @param {string} containerId - ID of the container element
     * @param {number} currentPage - Current page number
     * @param {Function} onPageChange - Callback for page change events
     */
    createPagination: function(response, containerId, currentPage, onPageChange) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        // Clear current pagination
        container.innerHTML = '';
        
        // If only one page, don't show pagination
        if (response.total_pages <= 1) return;
        
        // Create pagination element
        const paginationNav = document.createElement('nav');
        paginationNav.setAttribute('aria-label', 'Page navigation');
        
        const paginationList = document.createElement('ul');
        paginationList.className = 'pagination';
        
        // Previous button
        const prevItem = document.createElement('li');
        prevItem.className = `page-item ${currentPage <= 1 ? 'disabled' : ''}`;
        
        const prevLink = document.createElement('a');
        prevLink.className = 'page-link';
        prevLink.href = '#';
        prevLink.textContent = 'Previous';
        prevLink.setAttribute('aria-label', 'Previous');
        
        if (currentPage > 1) {
            prevLink.addEventListener('click', (e) => {
                e.preventDefault();
                onPageChange(currentPage - 1);
            });
        }
        
        prevItem.appendChild(prevLink);
        paginationList.appendChild(prevItem);
        
        // Page numbers
        const totalPages = response.total_pages;
        const maxVisiblePages = 5;
        
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        // Adjust if we're at the end
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            const pageItem = document.createElement('li');
            pageItem.className = `page-item ${i === currentPage ? 'active' : ''}`;
            
            const pageLink = document.createElement('a');
            pageLink.className = 'page-link';
            pageLink.href = '#';
            pageLink.textContent = i;
            
            if (i !== currentPage) {
                pageLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    onPageChange(i);
                });
            }
            
            pageItem.appendChild(pageLink);
            paginationList.appendChild(pageItem);
        }
        
        // Next button
        const nextItem = document.createElement('li');
        nextItem.className = `page-item ${currentPage >= totalPages ? 'disabled' : ''}`;
        
        const nextLink = document.createElement('a');
        nextLink.className = 'page-link';
        nextLink.href = '#';
        nextLink.textContent = 'Next';
        nextLink.setAttribute('aria-label', 'Next');
        
        if (currentPage < totalPages) {
            nextLink.addEventListener('click', (e) => {
                e.preventDefault();
                onPageChange(currentPage + 1);
            });
        }
        
        nextItem.appendChild(nextLink);
        paginationList.appendChild(nextItem);
        
        paginationNav.appendChild(paginationList);
        container.appendChild(paginationNav);
    }
};
