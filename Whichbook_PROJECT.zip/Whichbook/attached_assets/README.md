# Whichbook

A clone of whichbook.net with Flask backend API and client-side rendering using vanilla JavaScript.

## Overview

Whichbook is an interactive book recommendation application that allows users to:
- Find books based on mood sliders (happy to sad, funny to serious, etc.)
- Browse books by themes (adventure, family, friendship, etc.)
- Search for books by title or author
- View detailed book information and similar book recommendations

## Project Structure

```
whichbook/
│
├── app.py                 # Flask app configuration and database setup
├── main.py                # Entry point for the application
├── models.py              # SQLAlchemy database models
├── routes.py              # API route definitions
├── data_manager.py        # Business logic for data access
├── import_data.py         # Script to import data from JSON to database
│
├── data/                  # JSON data files
│   ├── books.json
│   ├── moods.json
│   └── themes.json
│
└── static/                # Frontend files
    ├── index.html         # Single-page application HTML
    ├── css/               # CSS stylesheets
    ├── js/                # JavaScript modules
    └── _redirects         # Netlify configuration (if using Netlify)
```

## Deployment Instructions

### 1. PythonAnywhere Deployment

1. Create a PythonAnywhere account and log in
2. Go to the "Web" tab and create a new web app with Flask
3. Upload and extract whichbook_complete.zip to your PythonAnywhere account
4. Configure your web app:
   - Set source code directory to the folder containing your project
   - Set working directory to the same folder
   - Set WSGI configuration file to point to wsgi_pythonanywhere.py
5. Create a PostgreSQL database and set the DATABASE_URL environment variable
6. Import data by running the import_data.py script:
   ```
   python import_data.py
   ```
7. Update configuration:
   - In static/js/config.js, change apiBaseUrl to your PythonAnywhere URL (e.g., 'https://username.pythonanywhere.com/api')
   - Set isDevelopment to false

### 2. Netlify Deployment (Optional, for separate frontend hosting)

1. Create a Netlify account and log in
2. Create a new site by uploading the static directory
3. Set basic build settings:
   - Build command: (leave blank)
   - Publish directory: static
4. In static/js/config.js, update apiBaseUrl to point to your PythonAnywhere API endpoint

## Development Setup

1. Clone the repository
2. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Set up a PostgreSQL database and set the DATABASE_URL environment variable
5. Import data:
   ```
   python import_data.py
   ```
6. Run the application:
   ```
   python main.py
   ```

## Technologies Used

- **Backend**: Flask, SQLAlchemy, PostgreSQL
- **Frontend**: HTML, CSS, JavaScript, Bootstrap 5
- **Deployment**: PythonAnywhere, Netlify (optional)

## License

This project is for educational purposes only. The original Whichbook.net is copyrighted by its owners.