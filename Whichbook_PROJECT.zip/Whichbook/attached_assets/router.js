/**
 * Router module for Whichbook
 * Handles client-side routing
 */
const Router = {
    /**
     * Initialize the router
     */
    init: function() {
        // Handle initial route
        this.handleRoute();
        
        // Listen for hash changes
        window.addEventListener('hashchange', () => {
            this.handleRoute();
        });
        
        // Set up search form
        const searchForm = document.getElementById('search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const searchInput = document.getElementById('search-input');
                if (searchInput && searchInput.value.trim()) {
                    window.location.hash = `#search/${encodeURIComponent(searchInput.value.trim())}`;
                }
            });
        }
        
        // Add event listeners to navigation links
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                if (href.startsWith('/')) {
                    window.location.hash = `#${href.substring(1)}`;
                } else {
                    window.location.hash = `#${href}`;
                }
            });
        });
    },
    
    /**
     * Handle current route
     */
    handleRoute: function() {
        // Get current hash without the # symbol
        const hash = window.location.hash.substring(1) || 'home';
        
        // Parse route path and params
        const [path, queryString] = hash.split('?');
        const params = new URLSearchParams(queryString || '');
        
        // Handle different routes
        if (path === 'home' || path === '') {
            this.showHomePage();
        } else if (path === 'moods') {
            this.showMoodsPage();
        } else if (path === 'themes') {
            this.showThemesPage(params);
        } else if (path.startsWith('book/')) {
            const bookId = path.split('/')[1];
            this.showBookDetailPage(bookId);
        } else if (path === 'books') {
            this.showBookListPage(params);
        } else if (path.startsWith('search/')) {
            // Format: #search/query/page
            const parts = path.split('/');
            const query = decodeURIComponent(parts[1] || '');
            const page = parseInt(parts[2] || '1');
            this.showSearchResultsPage(query, page);
        } else if (path === 'random') {
            this.showRandomBookPage();
        } else if (path === 'about') {
            this.showAboutPage();
        } else {
            this.show404Page();
        }
    },
    
    /**
     * Show home page
     */
    showHomePage: function() {
        const container = document.getElementById('app-container');
        if (!container) return;
        
        // Load home template
        const template = document.getElementById('home-template');
        container.innerHTML = '';
        container.appendChild(template.content.cloneNode(true));
        
        // Load featured books
        Books.loadFeaturedBooks();
        
        document.title = 'Whichbook - Find your next book';
    },
    
    /**
     * Show moods page with sliders
     */
    showMoodsPage: function() {
        const container = document.getElementById('app-container');
        if (!container) return;
        
        // Load moods template
        const template = document.getElementById('moods-template');
        container.innerHTML = '';
        container.appendChild(template.content.cloneNode(true));
        
        // Initialize mood sliders
        Sliders.initMoodSliders();
        
        document.title = 'Find Books by Mood - Whichbook';
    },
    
    /**
     * Show themes page
     * @param {URLSearchParams} params - URL parameters
     */
    showThemesPage: function(params) {
        const container = document.getElementById('app-container');
        if (!container) return;
        
        // Load themes template
        const template = document.getElementById('themes-template');
        container.innerHTML = '';
        container.appendChild(template.content.cloneNode(true));
        
        // Initialize theme selection
        Sliders.initThemeSelection();
        
        document.title = 'Find Books by Theme - Whichbook';
    },
    
    /**
     * Show book detail page
     * @param {string} bookId - Book ID
     */
    showBookDetailPage: function(bookId) {
        if (!bookId) {
            this.show404Page();
            return;
        }
        
        Books.displayBookDetail(bookId);
        
        // Title will be set in the displayBookDetail function
        document.title = 'Book Details - Whichbook';
    },
    
    /**
     * Show book list page with filters
     * @param {URLSearchParams} params - URL parameters
     */
    showBookListPage: function(params) {
        const container = document.getElementById('app-container');
        if (!container) return;
        
        // Load book list template
        const template = document.getElementById('book-list-template');
        container.innerHTML = '';
        container.appendChild(template.content.cloneNode(true));
        
        // Parse filter parameters
        const moodFilters = {};
        const themeIds = [];
        let page = 1;
        
        // Extract all parameters
        for (const [key, value] of params.entries()) {
            if (key.startsWith('mood_')) {
                const moodId = key.substring(5);
                moodFilters[moodId] = parseInt(value);
            } else if (key === 'theme') {
                themeIds.push(value);
            } else if (key === 'page') {
                page = parseInt(value);
            }
        }
        
        // Display books with filters
        Books.displayBookList({
            moodFilters: moodFilters,
            themeIds: themeIds,
            page: page
        });
        
        document.title = 'Book Results - Whichbook';
    },
    
    /**
     * Show search results page
     * @param {string} query - Search query
     * @param {number} page - Page number
     */
    showSearchResultsPage: function(query, page = 1) {
        if (!query) {
            window.location.hash = '#home';
            return;
        }
        
        Books.displaySearchResults(query, page);
        
        document.title = `Search: ${query} - Whichbook`;
    },
    
    /**
     * Show random book page
     */
    showRandomBookPage: function() {
        Books.displayRandomBook();
        
        document.title = 'Random Book - Whichbook';
    },
    
    /**
     * Show about page
     */
    showAboutPage: function() {
        const container = document.getElementById('app-container');
        if (!container) return;
        
        // Load about template
        const template = document.getElementById('about-template');
        container.innerHTML = '';
        container.appendChild(template.content.cloneNode(true));
        
        document.title = 'About Whichbook';
    },
    
    /**
     * Show 404 page
     */
    show404Page: function() {
        const container = document.getElementById('app-container');
        if (!container) return;
        
        container.innerHTML = `
            <div class="container text-center mt-5 pt-5">
                <h1>404 - Page Not Found</h1>
                <p class="lead">Sorry, the page you're looking for doesn't exist.</p>
                <a href="#home" class="btn btn-primary">Go to Homepage</a>
            </div>
        `;
        
        document.title = '404 Not Found - Whichbook';
    }
};
