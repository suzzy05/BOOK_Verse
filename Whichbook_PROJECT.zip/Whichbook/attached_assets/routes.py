from flask import jsonify, request, send_from_directory
from app import app
import os
from data_manager import DataManager
from flask import jsonify, render_template
# from .data_manager import get_all_books

data_manager = DataManager()

# @app.route('/api/books')
# def get_books():
#     books = get_all_books()
#     return jsonify(books)

# @app.route('/api/books/search')
# # def search_books():
# #     query = request.args.get('q', '')
# #     books = get_all_books()
# #     results = [b for b in books if query.lower() in b['Title'].lower() or query.lower() in b['Author'].lower()]
#     return jsonify(results)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/books')
def get_books():
    # Query parameters for filtering
    mood_filters = {}
    for param, value in request.args.items():
        if param.startswith('mood_'):
            mood_id = param[5:]  # Remove 'mood_' prefix
            try:
                mood_filters[mood_id] = int(value)
            except ValueError:
                pass
    
    # Get theme filters
    theme_ids = request.args.getlist('theme')
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    # Get filtered books
    books, total = data_manager.get_filtered_books(
        mood_filters, theme_ids, page, per_page
    )
    
    return jsonify({
        'books': books,
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': (total + per_page - 1) // per_page
    })

@app.route('/api/books/<book_id>')
def get_book(book_id):
    book = data_manager.get_book(book_id)
    if book:
        return jsonify(book)
    return jsonify({'error': 'Book not found'}), 404

@app.route('/api/books/<book_id>/similar')
def get_similar_books(book_id):
    similar_books = data_manager.get_similar_books(book_id)
    return jsonify(similar_books)

@app.route('/api/moods')
def get_moods():
    moods = data_manager.get_moods()
    return jsonify(moods)

@app.route('/api/themes')
def get_themes():
    themes = data_manager.get_themes()
    return jsonify(themes)

@app.route('/api/categories')
def get_categories():
    categories = data_manager.get_theme_categories()
    return jsonify(categories)

@app.route('/api/search')
def search_books():
    query = request.args.get('q', '')
    if not query:
        return jsonify({'error': 'Query parameter is required'}), 400
        
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    books, total = data_manager.search_books(query, page, per_page)
    
    return jsonify({
        'books': books,
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': (total + per_page - 1) // per_page
    })

# Catch-all route to serve the SPA
@app.route('/<path:path>')
def catch_all(path):
    # For any other path, serve the index.html to support client-side routing
    if os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory('static', 'index.html')
