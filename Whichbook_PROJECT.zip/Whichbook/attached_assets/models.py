from app import db
from sqlalchemy import Column, Integer, String, Text, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSONB

# Association table for many-to-many relationship between books and themes
book_theme = Table(
    'book_theme',
    db.metadata,
    Column('book_id', String(50), ForeignKey('book.id'), primary_key=True),
    Column('theme_id', String(50), ForeignKey('theme.id'), primary_key=True)
)

# Association table for similar books relationship
similar_books = Table(
    'similar_books',
    db.metadata,
    Column('book_id', String(50), ForeignKey('book.id'), primary_key=True),
    Column('similar_book_id', String(50), ForeignKey('book.id'), primary_key=True)
)

class Mood(db.Model):
    __tablename__ = 'mood'
    
    id = Column(String(50), primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    min_label = Column(String(50), nullable=False)
    max_label = Column(String(50), nullable=False)
    
    # Relationship with book mood ratings
    book_ratings = relationship('BookMoodRating', back_populates='mood')
    
    def __repr__(self):
        return f"<Mood {self.name}>"
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'min_label': self.min_label,
            'max_label': self.max_label
        }

class Theme(db.Model):
    __tablename__ = 'theme'
    
    id = Column(String(50), primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    category = Column(String(50), nullable=False)
    
    # Relationship with books (many-to-many)
    books = relationship('Book', secondary=book_theme, back_populates='themes')
    
    def __repr__(self):
        return f"<Theme {self.name}>"
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category
        }

class BookMoodRating(db.Model):
    __tablename__ = 'book_mood_rating'
    
    book_id = Column(String(50), ForeignKey('book.id'), primary_key=True)
    mood_id = Column(String(50), ForeignKey('mood.id'), primary_key=True)
    rating = Column(Integer, nullable=False)  # -100 to 100
    
    # Relationships
    book = relationship('Book', back_populates='mood_ratings')
    mood = relationship('Mood', back_populates='book_ratings')
    
    def __repr__(self):
        return f"<BookMoodRating {self.book_id} - {self.mood_id}: {self.rating}>"

class Book(db.Model):
    __tablename__ = 'book'
    
    id = Column(String(50), primary_key=True)
    title = Column(String(200), nullable=False)
    author = Column(String(100), nullable=False)
    cover_image = Column(String(500), nullable=False)
    description = Column(Text)
    publication_year = Column(Integer)
    isbn = Column(String(20))
    pages = Column(Integer)
    excerpt = Column(Text)
    
    # Relationships
    mood_ratings = relationship('BookMoodRating', back_populates='book', cascade='all, delete-orphan')
    themes = relationship('Theme', secondary=book_theme, back_populates='books')
    
    # Similar books (self-referential many-to-many)
    similar_to = relationship(
        'Book',
        secondary=similar_books,
        primaryjoin=id==similar_books.c.book_id,
        secondaryjoin=id==similar_books.c.similar_book_id,
        backref='similar_from'
    )
    
    def __repr__(self):
        return f"<Book {self.title}>"
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'author': self.author,
            'cover_image': self.cover_image,
            'description': self.description,
            'publication_year': self.publication_year,
            'isbn': self.isbn,
            'pages': self.pages,
            'excerpt': self.excerpt,
            'mood_ratings': {rating.mood_id: rating.rating for rating in self.mood_ratings},
            'themes': [theme.id for theme in self.themes],
            'similar_books': [book.id for book in self.similar_to]
        }
