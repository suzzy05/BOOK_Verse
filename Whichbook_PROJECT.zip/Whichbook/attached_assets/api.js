/**
 * API handling module for Whichbook
 * Provides functions to interact with the backend API
 */
const API = {
    /**
     * Base URL for API requests
     * This is configured in config.js file
     */
    baseURL: CONFIG.apiBaseUrl,
    
    /**
     * Fetch books with optional filtering
     * @param {Object} options - Filter options
     * @param {Object} options.moodFilters - Mood ratings to filter by
     * @param {Array} options.themeIds - Theme IDs to filter by
     * @param {number} options.page - Page number for pagination
     * @param {number} options.perPage - Items per page
     * @returns {Promise} Promise resolving to books data
     */
    getBooks: async function(options = {}) {
        const params = new URLSearchParams();
        
        // Add mood filters
        if (options.moodFilters) {
            for (const [moodId, value] of Object.entries(options.moodFilters)) {
                params.append(`mood_${moodId}`, value);
            }
        }
        
        // Add theme filters
        if (options.themeIds && options.themeIds.length > 0) {
            options.themeIds.forEach(themeId => {
                params.append('theme', themeId);
            });
        }
        
        // Add pagination
        if (options.page) params.append('page', options.page);
        if (options.perPage) params.append('per_page', options.perPage);
        
        const url = `${this.baseURL}/books?${params.toString()}`;
        return this.fetchJSON(url);
    },
    
    /**
     * Get a specific book by ID
     * @param {string} bookId - The ID of the book to retrieve
     * @returns {Promise} Promise resolving to book data
     */
    getBook: async function(bookId) {
        const url = `${this.baseURL}/books/${bookId}`;
        return this.fetchJSON(url);
    },
    
    /**
     * Get similar books for a specific book
     * @param {string} bookId - The ID of the book to find similar books for
     * @returns {Promise} Promise resolving to similar books data
     */
    getSimilarBooks: async function(bookId) {
        const url = `${this.baseURL}/books/${bookId}/similar`;
        return this.fetchJSON(url);
    },
    
    /**
     * Get all available moods
     * @returns {Promise} Promise resolving to moods data
     */
    getMoods: async function() {
        const url = `${this.baseURL}/moods`;
        return this.fetchJSON(url);
    },
    
    /**
     * Get all available themes
     * @returns {Promise} Promise resolving to themes data
     */
    getThemes: async function() {
        const url = `${this.baseURL}/themes`;
        return this.fetchJSON(url);
    },
    
    /**
     * Get all theme categories
     * @returns {Promise} Promise resolving to theme categories data
     */
    getThemeCategories: async function() {
        const url = `${this.baseURL}/categories`;
        return this.fetchJSON(url);
    },
    
    /**
     * Search for books
     * @param {string} query - Search query
     * @param {number} page - Page number for pagination
     * @param {number} perPage - Items per page
     * @returns {Promise} Promise resolving to search results
     */
    searchBooks: async function(query, page = 1, perPage = 20) {
        const params = new URLSearchParams({
            q: query,
            page: page,
            per_page: perPage
        });
        
        const url = `${this.baseURL}/search?${params.toString()}`;
        return this.fetchJSON(url);
    },
    
    /**
     * Helper function to fetch and parse JSON from an API endpoint
     * @param {string} url - The URL to fetch from
     * @returns {Promise} Promise resolving to parsed JSON
     */
    fetchJSON: async function(url) {
        try {
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`API request failed with status ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API request error:', error);
            throw error;
        }
    }
};
