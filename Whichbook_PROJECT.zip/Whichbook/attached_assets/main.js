/**
 * Main application entry point
 * Initializes all modules
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize books module
    Books.init();
    
    // Initialize router
    Router.init();
});
