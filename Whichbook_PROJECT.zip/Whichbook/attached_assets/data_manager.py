import logging
from typing import Dict, List, Tuple, Optional, Any
from sqlalchemy import func
from app import app, db
from models import Book, Mood, Theme, BookMoodRating
import os
import csv
import json
from flask import current_app

logger = logging.getLogger(__name__)

def load_all_books():
    books = []
    books_dir = os.path.join(current_app.static_folder, 'data', 'books')
    
    for filename in os.listdir(books_dir):
        if filename.endswith('.csv'):
            genre = filename.replace('.csv', '')
            filepath = os.path.join(books_dir, filename)
            
            with open(filepath, 'r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    row['Genre'] = genre  # Add genre information
                    books.append(row)
    
    return books

def save_books_to_json(books):
    json_path = os.path.join(current_app.static_folder, 'data', 'books.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(books, f, ensure_ascii=False, indent=2)

def get_all_books():
    json_path = os.path.join(current_app.static_folder, 'data', 'books.json')
    if not os.path.exists(json_path):
        books = load_all_books()
        save_books_to_json(books)
        return books
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)
    
class DataManager:
    def __init__(self):
        # No need to load JSON files or create indices anymore
        pass
    
    def get_moods(self) -> List[Dict[str, Any]]:
        """Get all moods."""
        with app.app_context():
            moods = Mood.query.all()
            return [mood.to_dict() for mood in moods]
    
    def get_themes(self) -> List[Dict[str, Any]]:
        """Get all themes."""
        with app.app_context():
            themes = Theme.query.all()
            return [theme.to_dict() for theme in themes]
    
    def get_theme_categories(self) -> List[str]:
        """Get all unique theme categories."""
        with app.app_context():
            categories = db.session.query(Theme.category).distinct().all()
            return [category[0] for category in categories]
    
    def get_book(self, book_id: str) -> Optional[Dict[str, Any]]:
        """Get a book by ID."""
        with app.app_context():
            book = Book.query.get(book_id)
            if book:
                return book.to_dict()
            return None
    
    def get_similar_books(self, book_id: str) -> List[Dict[str, Any]]:
        """Get books similar to the one with the given ID."""
        with app.app_context():
            book = Book.query.get(book_id)
            if not book:
                return []
            
            return [similar.to_dict() for similar in book.similar_to]
    
    def _calculate_mood_match_score(self, book_ratings: Dict[str, int], mood_filters: Dict[str, int]) -> float:
        """Calculate how well a book matches the given mood filters."""
        if not mood_filters:
            return 1.0  # No filters, perfect match
        
        if not book_ratings:
            return 0.0  # Book has no mood ratings, no match
        
        # Calculate the match score based on how close the book's mood ratings are
        # to the requested mood ratings
        total_diff = 0
        max_possible_diff = 0
        
        for mood_id, requested_rating in mood_filters.items():
            if mood_id in book_ratings:
                book_rating = book_ratings[mood_id]
                diff = abs(book_rating - requested_rating)
                total_diff += diff
                max_possible_diff += 200  # Max difference is 200 (-100 to 100)
            else:
                # If book doesn't have this mood rating, set max diff
                total_diff += 200
                max_possible_diff += 200
        
        if max_possible_diff == 0:
            return 1.0
        
        # Normalize to [0, 1] where 1 is perfect match
        return 1.0 - (total_diff / max_possible_diff)
    
    def get_filtered_books(
        self, 
        mood_filters: Dict[str, int], 
        theme_ids: List[str], 
        page: int = 1, 
        per_page: int = 20
    ) -> Tuple[List[Dict[str, Any]], int]:
        """Get books filtered by moods and themes, with pagination."""
        with app.app_context():
            # Start with a base query
            query = Book.query
            
            # Filter by themes if provided
            if theme_ids:
                for theme_id in theme_ids:
                    # This adds an inner join for each theme, effectively requiring
                    # that the book has all specified themes
                    query = query.filter(Book.themes.any(Theme.id == theme_id))
            
            # Get all matching books for mood filtering
            all_books = query.all()
            
            # If there are mood filters, calculate match scores and sort
            if mood_filters:
                scored_books = []
                for book in all_books:
                    # Convert book's mood ratings to a dictionary for easier matching
                    book_mood_ratings = {rating.mood_id: rating.rating for rating in book.mood_ratings}
                    score = self._calculate_mood_match_score(book_mood_ratings, mood_filters)
                    scored_books.append((book, score))
                
                # Sort by score, descending
                scored_books.sort(key=lambda x: x[1], reverse=True)
                filtered_books = [book for book, _ in scored_books]
            else:
                filtered_books = all_books
            
            # Apply pagination
            total = len(filtered_books)
            start_idx = (page - 1) * per_page
            end_idx = start_idx + per_page
            paginated_books = filtered_books[start_idx:end_idx]
            
            # Convert to dictionaries for JSON serialization
            return [book.to_dict() for book in paginated_books], total
    
    def search_books(
        self, 
        query: str, 
        page: int = 1, 
        per_page: int = 20
    ) -> Tuple[List[Dict[str, Any]], int]:
        """Search books by title or author."""
        with app.app_context():
            # Use ILIKE for case-insensitive search
            search_query = f"%{query}%"
            books_query = Book.query.filter(
                db.or_(
                    Book.title.ilike(search_query),
                    Book.author.ilike(search_query)
                )
            )
            
            # Get total count for pagination
            total = books_query.count()
            
            # Apply pagination
            books = books_query.offset((page - 1) * per_page).limit(per_page).all()
            
            # Convert to dictionaries for JSON serialization
            return [book.to_dict() for book in books], total
