import json
import os
import sys
from app import app, db
from models import Book, Mood, Theme, BookMoodRating
from data_manager import load_all_books, save_books_to_json

def initialize_data():
    print("Loading all books from CSV files...")
    books = load_all_books()
    print(f"Loaded {len(books)} books")
    print("Saving to JSON...")
    save_books_to_json(books)
    print("Data initialization complete!")

if __name__ == '__main__':
    initialize_data()

def load_json(filename):
    """Load data from a JSON file."""
    try:
        filepath = os.path.join(app.config['DATA_FOLDER'], filename)
        with open(filepath, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: File {filename} not found.")
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: Could not parse JSON from {filename}.")
        sys.exit(1)

def import_moods():
    """Import moods from JSON file into database."""
    print("Importing moods...")
    moods_data = load_json('moods.json')
    
    for mood_data in moods_data:
        mood = Mood(
            id=mood_data['id'],
            name=mood_data['name'],
            description=mood_data['description'],
            min_label=mood_data['min_label'],
            max_label=mood_data['max_label']
        )
        db.session.add(mood)
    
    db.session.commit()
    print(f"Successfully imported {len(moods_data)} moods.")

def import_themes():
    """Import themes from JSON file into database."""
    print("Importing themes...")
    themes_data = load_json('themes.json')
    
    for theme_data in themes_data:
        theme = Theme(
            id=theme_data['id'],
            name=theme_data['name'],
            description=theme_data['description'],
            category=theme_data['category']
        )
        db.session.add(theme)
    
    db.session.commit()
    print(f"Successfully imported {len(themes_data)} themes.")

def import_books():
    """Import books from JSON file into database."""
    print("Importing books...")
    books_data = load_json('books.json')
    
    # Import books without relationships first
    for book_data in books_data:
        book = Book(
            id=book_data['id'],
            title=book_data['title'],
            author=book_data['author'],
            cover_image=book_data['cover_image'],
            description=book_data['description'],
            publication_year=book_data['publication_year'],
            isbn=book_data.get('isbn'),
            pages=book_data.get('pages'),
            excerpt=book_data.get('excerpt')
        )
        db.session.add(book)
    
    db.session.commit()
    
    # Add relationships after all books exist
    for book_data in books_data:
        book = Book.query.get(book_data['id'])
        
        # Add mood ratings
        if 'mood_ratings' in book_data:
            for mood_id, rating in book_data['mood_ratings'].items():
                mood_rating = BookMoodRating(
                    book_id=book.id,
                    mood_id=mood_id,
                    rating=rating
                )
                db.session.add(mood_rating)
        
        # Add themes
        if 'themes' in book_data:
            for theme_id in book_data['themes']:
                theme = Theme.query.get(theme_id)
                if theme:
                    book.themes.append(theme)
        
        # Add similar books
        if 'similar_books' in book_data and book_data['similar_books']:
            for similar_id in book_data['similar_books']:
                similar_book = Book.query.get(similar_id)
                if similar_book:
                    book.similar_to.append(similar_book)
    
    db.session.commit()
    print(f"Successfully imported {len(books_data)} books.")

def main():
    """Main function to import all data."""
    with app.app_context():
        print("Creating database tables...")
        db.create_all()
        
        # Check if data already exists
        if Mood.query.count() > 0 or Theme.query.count() > 0 or Book.query.count() > 0:
            response = input("Database already contains data. Do you want to clear it and import again? (y/n): ")
            if response.lower() != 'y':
                print("Import cancelled.")
                return
            
            print("Clearing existing data...")
            db.session.query(BookMoodRating).delete()
            db.session.query(Book).delete()
            db.session.query(Theme).delete()
            db.session.query(Mood).delete()
            db.session.commit()
        
        # Import data
        import_moods()
        import_themes()
        import_books()
        
        print("Data import completed successfully!")

if __name__ == "__main__":
    main()