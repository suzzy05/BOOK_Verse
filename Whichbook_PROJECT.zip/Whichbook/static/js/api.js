/**
 * API module for Whichbook
 * Handles communication with the backend API
 */
const API = {
    /**
     * Get books with optional filters
     * @param {Object} options - Filter options
     * @returns {Promise<Object>} Response with books and metadata
     */
    getBooks: async function(options = {}) {
        try {
            // Build query parameters
            const params = new URLSearchParams();
            
            // Add pagination
            if (options.page) params.append('page', options.page);
            if (options.perPage) params.append('perPage', options.perPage);
            
            // Add mood filters
            if (options.moodFilters && typeof options.moodFilters === 'object') {
                for (const [moodId, value] of Object.entries(options.moodFilters)) {
                    params.append(`mood_${moodId}`, value);
                }
            }
            
            // Add theme filters
            if (options.themeIds && Array.isArray(options.themeIds)) {
                options.themeIds.forEach(themeId => {
                    params.append('theme', themeId);
                });
            }
            
            // Make API request
            const response = await fetch(`${CONFIG.apiBaseUrl}/books?${params.toString()}`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API error in getBooks:', error);
            throw error;
        }
    },
    
    /**
     * Get a single book by ID
     * @param {string} bookId - Book ID
     * @returns {Promise<Object>} Book data
     */
    getBook: async function(bookId) {
        try {
            const response = await fetch(`${CONFIG.apiBaseUrl}/books/${bookId}`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`API error in getBook(${bookId}):`, error);
            throw error;
        }
    },
    
    /**
     * Search books by query
     * @param {string} query - Search query
     * @param {number} page - Page number
     * @param {number} perPage - Items per page
     * @returns {Promise<Object>} Response with books and metadata
     */
    searchBooks: async function(query, page = 1, perPage = 20) {
        try {
            const params = new URLSearchParams({
                q: query,
                page: page,
                perPage: perPage
            });
            
            const response = await fetch(`${CONFIG.apiBaseUrl}/books/search?${params.toString()}`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`API error in searchBooks(${query}):`, error);
            throw error;
        }
    },
    
    /**
     * Get a random book
     * @returns {Promise<Object>} Book data
     */
    getRandomBook: async function() {
        try {
            const response = await fetch(`${CONFIG.apiBaseUrl}/books/random`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API error in getRandomBook:', error);
            throw error;
        }
    },
    
    /**
     * Get books similar to the given book
     * @param {string} bookId - Book ID
     * @param {number} count - Number of similar books to return
     * @returns {Promise<Array>} Array of similar books
     */
    getSimilarBooks: async function(bookId, count = 4) {
        try {
            const params = new URLSearchParams({
                count: count
            });
            
            const response = await fetch(`${CONFIG.apiBaseUrl}/books/${bookId}/similar?${params.toString()}`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`API error in getSimilarBooks(${bookId}):`, error);
            throw error;
        }
    },
    
    /**
     * Get all available moods
     * @returns {Promise<Array>} Array of moods
     */
    getMoods: async function() {
        try {
            const response = await fetch(`${CONFIG.apiBaseUrl}/moods`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API error in getMoods:', error);
            throw error;
        }
    },
    
    /**
     * Get all available themes
     * @returns {Promise<Array>} Array of themes
     */
    getThemes: async function() {
        try {
            const response = await fetch(`${CONFIG.apiBaseUrl}/themes`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API error in getThemes:', error);
            throw error;
        }
    },
    
    /**
     * Get all theme categories
     * @returns {Promise<Array>} Array of category names
     */
    getThemeCategories: async function() {
        try {
            const response = await fetch(`${CONFIG.apiBaseUrl}/themes/categories`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API error in getThemeCategories:', error);
            throw error;
        }
    }
};
