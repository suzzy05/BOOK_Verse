/**
 * Books module for Whichbook
 * Handles book display and interactions
 */
const Books = {
    /**
     * Initialize the book functionality
     */
    init: function() {
        // No initialization needed for now
    },
    
    /**
     * Load featured books for the homepage
     */
    loadFeaturedBooks: async function() {
        try {
            const container = document.getElementById('featured-books');
            if (!container) return;
            
            // Clear current content and show loading indicator
            container.innerHTML = '<div class="text-center w-100"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get some books (no filters, just first page)
            const response = await API.getBooks({ page: 1, perPage: 4 });
            
            // Clear loading indicator
            container.innerHTML = '';
            
            // Render books
            response.books.forEach(book => {
                container.appendChild(this.createBookCard(book));
            });
        } catch (error) {
            console.error('Error loading featured books:', error);
            const container = document.getElementById('featured-books');
            if (container) {
                container.innerHTML = '<div class="alert alert-danger w-100">Error loading books. Please try again later.</div>';
            }
        }
    },
    
    /**
     * Create a book card element
     * @param {Object} book - Book data
     * @returns {HTMLElement} Book card element
     */
    createBookCard: function(book) {
        // Clone the template
        const template = document.getElementById('book-card-template');
        const bookCard = template.content.cloneNode(true);
        
        // Set book data
        const img = bookCard.querySelector('.book-cover-img');
        img.src = book.cover_image;
        img.alt = `${book.title} cover`;
        
        bookCard.querySelector('.book-title').textContent = book.title;
        bookCard.querySelector('.book-author').textContent = book.author;
        
        const viewBookLink = bookCard.querySelector('.view-book');
        viewBookLink.href = `/book/${book.id}`;
        viewBookLink.setAttribute('data-book-id', book.id);
        
        viewBookLink.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.hash = `#book/${book.id}`;
        });
        
        return bookCard.children[0]; // Return the actual element, not the document fragment
    },
    
    /**
     * Display book list based on filters
     * @param {Object} options - Filter options (moodFilters, themeIds, page)
     */
    displayBookList: async function(options = {}) {
        try {
            const container = document.getElementById('book-list');
            if (!container) return;
            
            // Set default values
            const page = options.page || 1;
            const perPage = options.perPage || 20;
            
            // Clear current content and show loading indicator
            container.innerHTML = '<div class="text-center w-100"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get filtered books
            const response = await API.getBooks({
                moodFilters: options.moodFilters,
                themeIds: options.themeIds,
                page: page,
                perPage: perPage
            });
            
            // Clear loading indicator
            container.innerHTML = '';
            
            // Update results description
            const resultsDescription = document.getElementById('results-description');
            if (resultsDescription) {
                resultsDescription.textContent = `Found ${response.total} book${response.total !== 1 ? 's' : ''}`;
            }
            
            // Handle no results
            if (response.books.length === 0) {
                container.innerHTML = '<div class="col-12 text-center"><div class="alert alert-info">No books found matching your criteria. Here are some random book suggestions instead:</div></div>';
                // Load random books as alternatives
                this.loadRandomBooks(container, 4);
                return;
            }
            
            // Render books
            response.books.forEach(book => {
                container.appendChild(this.createBookCard(book));
            });
            
            // Create pagination
            this.createPagination(response, 'pagination-container', page, (newPage) => {
                options.page = newPage;
                this.displayBookList(options);
                window.scrollTo(0, 0);
            });
        } catch (error) {
            console.error('Error displaying book list:', error);
            const container = document.getElementById('book-list');
            if (container) {
                container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error loading books. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Display a single book's details
     * @param {string} bookId - ID of the book to display
     */
    displayBookDetail: async function(bookId) {
        try {
            const container = document.getElementById('app-container');
            if (!container) return;
            
            // Show loading indicator
            container.innerHTML = '<div class="container text-center mt-5 pt-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Fetch book data
            const book = await API.getBook(bookId);
            
            // Get similar books
            const similarBooks = await API.getSimilarBooks(bookId);
            
            // Clone template
            const template = document.getElementById('book-detail-template');
            const bookDetail = template.content.cloneNode(true);
            
            // Set basic book info
            bookDetail.querySelector('#book-cover').src = book.cover_image;
            bookDetail.querySelector('#book-cover').alt = `${book.title} cover`;
            bookDetail.querySelector('#book-title').textContent = book.title;
            bookDetail.querySelector('#book-author').textContent = book.author;
            bookDetail.querySelector('#book-year').textContent = book.publication_year;
            bookDetail.querySelector('#book-isbn').textContent = book.isbn;
            bookDetail.querySelector('#book-pages').textContent = book.pages;
            bookDetail.querySelector('#book-description').textContent = book.description;
            
            // Set mood ratings
            const moodRatingsContainer = bookDetail.querySelector('#book-mood-ratings');
            
            if (book.mood_ratings) {
                // Fetch all moods to get their labels
                const moods = await API.getMoods();
                const moodsMap = new Map(moods.map(mood => [mood.id, mood]));
                
                // Create a mood rating display for each mood
                for (const [moodId, rating] of Object.entries(book.mood_ratings)) {
                    const mood = moodsMap.get(moodId);
                    if (!mood) continue;
                    
                    const ratingElem = document.createElement('div');
                    ratingElem.className = 'mood-rating-display';
                    
                    // Determine which label to show based on rating
                    let ratingLabel = '';
                    if (rating < -50) {
                        ratingLabel = mood.min_label;
                    } else if (rating > 50) {
                        ratingLabel = mood.max_label;
                    } else {
                        ratingLabel = `${mood.min_label} ↔ ${mood.max_label}`;
                    }
                    
                    // Create the HTML
                    ratingElem.innerHTML = `
                        <div class="mood-rating-name">${mood.name}</div>
                        <div class="mood-rating-bar-container">
                            <div class="mood-rating-bar ${rating < 0 ? 'positive' : 'negative'}" 
                                 style="width: ${Math.abs(rating)}%;"></div>
                        </div>
                    `;
                    
                    moodRatingsContainer.appendChild(ratingElem);
                }
            } else {
                moodRatingsContainer.innerHTML = '<p>No mood ratings available for this book.</p>';
            }
            
            // Set themes
            const themesContainer = bookDetail.querySelector('#book-themes');
            
            if (book.themes && book.themes.length > 0) {
                // Fetch all themes to get their full info
                const themes = await API.getThemes();
                const themesMap = new Map(themes.map(theme => [theme.id, theme]));
                
                const themesDiv = document.createElement('div');
                book.themes.forEach(themeId => {
                    const theme = themesMap.get(themeId);
                    if (!theme) return;
                    
                    const themeTag = document.createElement('span');
                    themeTag.className = 'theme-tag';
                    themeTag.textContent = theme.name;
                    themeTag.addEventListener('click', () => {
                        window.location.hash = `#themes/?theme=${themeId}`;
                    });
                    
                    themesDiv.appendChild(themeTag);
                });
                
                themesContainer.appendChild(themesDiv);
            } else {
                themesContainer.innerHTML = '<p>No themes available for this book.</p>';
            }
            
            // Set excerpt if available
            const excerptContainer = bookDetail.querySelector('#book-excerpt-container');
            const excerptText = bookDetail.querySelector('#book-excerpt');
            
            if (book.excerpt) {
                excerptText.textContent = book.excerpt;
            } else {
                excerptContainer.style.display = 'none';
            }
            
            // Set similar books
            const similarBooksContainer = bookDetail.querySelector('#similar-books');
            
            if (similarBooks && similarBooks.length > 0) {
                similarBooks.forEach(similarBook => {
                    similarBooksContainer.appendChild(this.createBookCard(similarBook));
                });
            } else {
                bookDetail.querySelector('.similar-books-section').style.display = 'none';
            }
            
            // Replace content
            container.innerHTML = '';
            container.appendChild(bookDetail);
            
            // Update document title
            document.title = `${book.title} - Whichbook`;
            
            // Scroll to top
            window.scrollTo(0, 0);
        } catch (error) {
            console.error('Error displaying book details:', error);
            const container = document.getElementById('app-container');
            if (container) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">Error loading book details. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Load random books into a container
     * @param {HTMLElement} container - Container to add books to
     * @param {number} count - Number of books to load
     */
    loadRandomBooks: async function(container, count = 4) {
        try {
            // Add loading indicator
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'text-center w-100';
            loadingDiv.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';
            container.appendChild(loadingDiv);
            
            // Get random books
            const promises = [];
            for (let i = 0; i < count; i++) {
                promises.push(API.getRandomBook());
            }
            
            const books = await Promise.all(promises);
            
            // Remove loading indicator
            container.removeChild(loadingDiv);
            
            // Add books to container
            books.forEach(book => {
                container.appendChild(this.createBookCard(book));
            });
        } catch (error) {
            console.error('Error loading random books:', error);
            container.innerHTML += '<div class="col-12"><div class="alert alert-danger">Error loading random books. Please try again later.</div></div>';
        }
    },

    /**
     * Display search results
     * @param {string} query - Search query
     * @param {number} page - Page number
     */
    displaySearchResults: async function(query, page = 1) {
        try {
            const container = document.getElementById('app-container');
            if (!container) return;
            
            // Show loading indicator
            container.innerHTML = '<div class="container text-center mt-5 pt-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Fetch search results
            const perPage = 20;
            const response = await API.searchBooks(query, page, perPage);
            
            // Clone template
            const template = document.getElementById('search-results-template');
            const searchResults = template.content.cloneNode(true);
            
            // Set search query display
            const queryDisplay = searchResults.querySelector('#search-query-display');
            queryDisplay.textContent = `Search results for "${query}"`;
            
            // Get results container and populate it
            const resultsContainer = searchResults.querySelector('#search-results-list');
            
            // Update results count
            const resultsCount = searchResults.querySelector('#search-results-count');
            resultsCount.textContent = `Found ${response.total} book${response.total !== 1 ? 's' : ''}`;
            
            // Handle no results
            if (response.books.length === 0) {
                resultsContainer.innerHTML = '<div class="col-12 text-center"><div class="alert alert-info">No books found matching your search. Here are some random book suggestions instead:</div></div>';
                // Load random books as alternatives
                this.loadRandomBooks(resultsContainer, 4);
            } else {
                // Add books to container
                response.books.forEach(book => {
                    resultsContainer.appendChild(this.createBookCard(book));
                });
                
                // Create pagination
                this.createPagination(response, 'search-pagination', page, (newPage) => {
                    window.location.hash = `#search/${encodeURIComponent(query)}/${newPage}`;
                });
            }
            
            // Replace content
            container.innerHTML = '';
            container.appendChild(searchResults);
            
            // Update document title
            document.title = `Search: ${query} - Whichbook`;
            
            // Scroll to top
            window.scrollTo(0, 0);
        } catch (error) {
            console.error('Error displaying search results:', error);
            const container = document.getElementById('app-container');
            if (container) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">Error searching books. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Display a random book
     */
    displayRandomBook: async function() {
        try {
            const container = document.getElementById('app-container');
            if (!container) return;
            
            // Show loading indicator
            container.innerHTML = '<div class="container text-center mt-5 pt-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get a random book
            const book = await API.getRandomBook();
            
            // Redirect to the book detail page
            window.location.hash = `#book/${book.id}`;
        } catch (error) {
            console.error('Error getting random book:', error);
            const container = document.getElementById('app-container');
            if (container) {
                container.innerHTML = '<div class="container mt-5 pt-5"><div class="alert alert-danger">Error finding a random book. Please try again later.</div></div>';
            }
        }
    },
    
    /**
     * Create pagination controls
     * @param {Object} response - API response containing pagination info
     * @param {string} containerId - ID of container element
     * @param {number} currentPage - Current page number
     * @param {Function} onPageChange - Callback function when page changes
     */
    createPagination: function(response, containerId, currentPage, onPageChange) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        // Clear current content
        container.innerHTML = '';
        
        // Calculate total pages
        const totalPages = Math.ceil(response.total / response.perPage);
        
        // If only one page, don't show pagination
        if (totalPages <= 1) return;
        
        // Create pagination element
        const pagination = document.createElement('nav');
        pagination.setAttribute('aria-label', 'Pagination');
        
        const pageList = document.createElement('ul');
        pageList.className = 'pagination justify-content-center';
        
        // Previous button
        const prevItem = document.createElement('li');
        prevItem.className = `page-item ${currentPage <= 1 ? 'disabled' : ''}`;
        
        const prevLink = document.createElement('a');
        prevLink.className = 'page-link';
        prevLink.href = '#';
        prevLink.setAttribute('aria-label', 'Previous');
        prevLink.innerHTML = '<span aria-hidden="true">&laquo;</span>';
        
        if (currentPage > 1) {
            prevLink.addEventListener('click', (e) => {
                e.preventDefault();
                onPageChange(currentPage - 1);
            });
        }
        
        prevItem.appendChild(prevLink);
        pageList.appendChild(prevItem);
        
        // Page numbers
        const maxPagesToShow = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
        let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
        
        // Adjust if we're near the end
        if (endPage - startPage + 1 < maxPagesToShow) {
            startPage = Math.max(1, endPage - maxPagesToShow + 1);
        }
        
        // First page if not in range
        if (startPage > 1) {
            const firstItem = document.createElement('li');
            firstItem.className = 'page-item';
            
            const firstLink = document.createElement('a');
            firstLink.className = 'page-link';
            firstLink.href = '#';
            firstLink.textContent = '1';
            
            firstLink.addEventListener('click', (e) => {
                e.preventDefault();
                onPageChange(1);
            });
            
            firstItem.appendChild(firstLink);
            pageList.appendChild(firstItem);
            
            // Ellipsis if needed
            if (startPage > 2) {
                const ellipsisItem = document.createElement('li');
                ellipsisItem.className = 'page-item disabled';
                
                const ellipsisSpan = document.createElement('span');
                ellipsisSpan.className = 'page-link';
                ellipsisSpan.innerHTML = '&hellip;';
                
                ellipsisItem.appendChild(ellipsisSpan);
                pageList.appendChild(ellipsisItem);
            }
        }
        
        // Page numbers
        for (let i = startPage; i <= endPage; i++) {
            const pageItem = document.createElement('li');
            pageItem.className = `page-item ${i === currentPage ? 'active' : ''}`;
            
            const pageLink = document.createElement('a');
            pageLink.className = 'page-link';
            pageLink.href = '#';
            pageLink.textContent = i;
            
            if (i === currentPage) {
                pageLink.setAttribute('aria-current', 'page');
            } else {
                pageLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    onPageChange(i);
                });
            }
            
            pageItem.appendChild(pageLink);
            pageList.appendChild(pageItem);
        }
        
        // Last page if not in range
        if (endPage < totalPages) {
            // Ellipsis if needed
            if (endPage < totalPages - 1) {
                const ellipsisItem = document.createElement('li');
                ellipsisItem.className = 'page-item disabled';
                
                const ellipsisSpan = document.createElement('span');
                ellipsisSpan.className = 'page-link';
                ellipsisSpan.innerHTML = '&hellip;';
                
                ellipsisItem.appendChild(ellipsisSpan);
                pageList.appendChild(ellipsisItem);
            }
            
            const lastItem = document.createElement('li');
            lastItem.className = 'page-item';
            
            const lastLink = document.createElement('a');
            lastLink.className = 'page-link';
            lastLink.href = '#';
            lastLink.textContent = totalPages;
            
            lastLink.addEventListener('click', (e) => {
                e.preventDefault();
                onPageChange(totalPages);
            });
            
            lastItem.appendChild(lastLink);
            pageList.appendChild(lastItem);
        }
        
        // Next button
        const nextItem = document.createElement('li');
        nextItem.className = `page-item ${currentPage >= totalPages ? 'disabled' : ''}`;
        
        const nextLink = document.createElement('a');
        nextLink.className = 'page-link';
        nextLink.href = '#';
        nextLink.setAttribute('aria-label', 'Next');
        nextLink.innerHTML = '<span aria-hidden="true">&raquo;</span>';
        
        if (currentPage < totalPages) {
            nextLink.addEventListener('click', (e) => {
                e.preventDefault();
                onPageChange(currentPage + 1);
            });
        }
        
        nextItem.appendChild(nextLink);
        pageList.appendChild(nextItem);
        
        pagination.appendChild(pageList);
        container.appendChild(pagination);
    }
};
