/**
 * Configuration settings for the Whichbook application
 * Edit this file to update your deployment settings
 */
const CONFIG = {
    /**
     * API URL Configuration
     * 
     * For local development: Use relative path '/api'
     * For production: Use the full URL to your PythonAnywhere instance
     * 
     * Examples:
     * - Local: '/api'
     * - Production: 'https://your-username.pythonanywhere.com/api'
     */
    apiBaseUrl: '/api',
    
    /**
     * Is this a development environment?
     * Set to false for production deployment
     */
    isDevelopment: true
};
