/**
 * Sliders module for Whichbook
 * Handles mood sliders and theme selection
 */
const Sliders = {
    // Store mood sliders data
    moodSliders: [],
    
    // Store selected themes
    selectedThemes: [],
    
    /**
     * Initialize mood sliders
     */
    initMoodSliders: async function() {
        try {
            const container = document.getElementById('mood-sliders');
            if (!container) return;
            
            // Clear current sliders
            container.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get moods from API
            const moods = await API.getMoods();
            this.moodSliders = moods;
            
            // Clear loading indicator
            container.innerHTML = '';
            
            // Create sliders
            moods.forEach(mood => {
                // Create slider container
                const sliderContainer = document.createElement('div');
                sliderContainer.className = 'mood-slider';
                sliderContainer.setAttribute('data-mood-id', mood.id);
                
                // Create slider title and description
                const sliderTitle = document.createElement('h3');
                sliderTitle.textContent = mood.name;
                
                const sliderDescription = document.createElement('p');
                sliderDescription.textContent = mood.description;
                
                // Create slider labels
                const sliderLabels = document.createElement('div');
                sliderLabels.className = 'slider-labels';
                
                const minLabel = document.createElement('span');
                minLabel.className = 'slider-label min';
                minLabel.textContent = mood.min_label;
                
                const maxLabel = document.createElement('span');
                maxLabel.className = 'slider-label max';
                maxLabel.textContent = mood.max_label;
                
                sliderLabels.appendChild(minLabel);
                sliderLabels.appendChild(maxLabel);
                
                // Create slider input container
                const sliderInputContainer = document.createElement('div');
                sliderInputContainer.className = 'slider-container';
                
                const sliderTrack = document.createElement('div');
                sliderTrack.className = 'slider-track';
                
                // Create range input
                const sliderInput = document.createElement('input');
                sliderInput.type = 'range';
                sliderInput.className = 'slider-input';
                sliderInput.id = `slider-${mood.id}`;
                sliderInput.min = '-100';
                sliderInput.max = '100';
                sliderInput.value = '0';
                
                // Create value display
                const sliderValue = document.createElement('div');
                sliderValue.className = 'slider-value';
                sliderValue.textContent = '0';
                
                // Update value display on slider input change
                sliderInput.addEventListener('input', (e) => {
                    const value = e.target.value;
                    sliderValue.textContent = value;
                    
                    // Update slider value position
                    const percent = (parseFloat(value) + 100) / 200;
                    const position = percent * sliderInput.offsetWidth;
                    sliderValue.style.left = `${position}px`;
                });
                
                // Add elements to container
                sliderInputContainer.appendChild(sliderTrack);
                sliderInputContainer.appendChild(sliderInput);
                sliderInputContainer.appendChild(sliderValue);
                
                sliderContainer.appendChild(sliderTitle);
                sliderContainer.appendChild(sliderDescription);
                sliderContainer.appendChild(sliderLabels);
                sliderContainer.appendChild(sliderInputContainer);
                
                container.appendChild(sliderContainer);
            });
            
            // Add event listeners for buttons
            const searchButton = document.getElementById('search-by-mood');
            if (searchButton) {
                searchButton.addEventListener('click', () => {
                    this.searchByMoodFilters();
                });
            }
            
            const resetButton = document.getElementById('reset-sliders');
            if (resetButton) {
                resetButton.addEventListener('click', () => {
                    this.resetMoodSliders();
                });
            }
        } catch (error) {
            console.error('Error initializing mood sliders:', error);
            const container = document.getElementById('mood-sliders');
            if (container) {
                container.innerHTML = '<div class="alert alert-danger">Error loading mood sliders. Please try again later.</div>';
            }
        }
    },
    
    /**
     * Reset all mood sliders to center position
     */
    resetMoodSliders: function() {
        this.moodSliders.forEach(mood => {
            const slider = document.getElementById(`slider-${mood.id}`);
            if (slider) {
                slider.value = '0';
                // Trigger input event to update value display
                slider.dispatchEvent(new Event('input'));
            }
        });
    },
    
    /**
     * Get current values of all mood sliders
     * @returns {Object} Mood filter values
     */
    getMoodFilters: function() {
        const moodFilters = {};
        
        this.moodSliders.forEach(mood => {
            const slider = document.getElementById(`slider-${mood.id}`);
            if (slider) {
                const value = parseInt(slider.value);
                // Only include values that aren't zero (neutral)
                if (value !== 0) {
                    moodFilters[mood.id] = value;
                }
            }
        });
        
        return moodFilters;
    },
    
    /**
     * Search for books based on mood slider values
     */
    searchByMoodFilters: function() {
        const moodFilters = this.getMoodFilters();
        
        // Navigate to the book list with the mood filters
        const filtersQuery = Object.entries(moodFilters)
            .map(([key, value]) => `mood_${key}=${value}`)
            .join('&');
        
        window.location.hash = `books?${filtersQuery}`;
    },
    
    /**
     * Initialize theme selection
     */
    initThemeSelection: async function() {
        try {
            const container = document.getElementById('themes-container');
            if (!container) return;
            
            // Clear current content
            container.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            // Get themes and categories
            const themes = await API.getThemes();
            const categories = await API.getThemeCategories();
            
            // Clear loading indicator
            container.innerHTML = '';
            
            // Group themes by category
            const themesByCategory = {};
            categories.forEach(category => {
                themesByCategory[category] = themes.filter(theme => theme.category === category);
            });
            
            // Create theme selection UI
            for (const [category, categoryThemes] of Object.entries(themesByCategory)) {
                // Create category container
                const categoryContainer = document.createElement('div');
                categoryContainer.className = 'theme-category';
                
                // Create category title
                const categoryTitle = document.createElement('h3');
                categoryTitle.textContent = category;
                categoryContainer.appendChild(categoryTitle);
                
                // Create themes
                const themesContainer = document.createElement('div');
                themesContainer.className = 'themes-list';
                
                categoryThemes.forEach(theme => {
                    const themeTag = document.createElement('span');
                    themeTag.className = 'theme-tag';
                    themeTag.setAttribute('data-theme-id', theme.id);
                    themeTag.textContent = theme.name;
                    themeTag.title = theme.description;
                    
                    // Toggle selection on click
                    themeTag.addEventListener('click', () => {
                        this.toggleThemeSelection(themeTag, theme.id);
                    });
                    
                    themesContainer.appendChild(themeTag);
                });
                
                categoryContainer.appendChild(themesContainer);
                container.appendChild(categoryContainer);
            }
            
            // Add event listeners for buttons
            const searchButton = document.getElementById('search-by-themes');
            if (searchButton) {
                searchButton.addEventListener('click', () => {
                    this.searchByThemes();
                });
            }
            
            const clearButton = document.getElementById('clear-themes');
            if (clearButton) {
                clearButton.addEventListener('click', () => {
                    this.clearThemeSelection();
                });
            }
            
            // Check URL for theme parameters
            this.parseThemeParams();
        } catch (error) {
            console.error('Error initializing theme selection:', error);
            const container = document.getElementById('themes-container');
            if (container) {
                container.innerHTML = '<div class="alert alert-danger">Error loading themes. Please try again later.</div>';
            }
        }
    },
    
    /**
     * Parse theme parameters from URL and select them
     */
    parseThemeParams: function() {
        const urlParams = new URLSearchParams(window.location.hash.split('?')[1] || '');
        const themes = urlParams.getAll('theme');
        
        if (themes.length > 0) {
            // Reset selection first
            this.clearThemeSelection();
            
            // Select themes
            themes.forEach(themeId => {
                const themeTag = document.querySelector(`.theme-tag[data-theme-id="${themeId}"]`);
                if (themeTag) {
                    this.toggleThemeSelection(themeTag, themeId);
                }
            });
        }
    },
    
    /**
     * Toggle selection of a theme
     * @param {HTMLElement} themeTag - Theme tag element
     * @param {string} themeId - Theme ID
     */
    toggleThemeSelection: function(themeTag, themeId) {
        if (themeTag.classList.contains('selected')) {
            // Deselect
            themeTag.classList.remove('selected');
            this.selectedThemes = this.selectedThemes.filter(id => id !== themeId);
        } else {
            // Select
            themeTag.classList.add('selected');
            this.selectedThemes.push(themeId);
        }
    },
    
    /**
     * Clear all theme selections
     */
    clearThemeSelection: function() {
        // Clear selected themes array
        this.selectedThemes = [];
        
        // Remove selected class from all theme tags
        const themeTags = document.querySelectorAll('.theme-tag');
        themeTags.forEach(tag => {
            tag.classList.remove('selected');
        });
    },
    
    /**
     * Search for books based on selected themes
     */
    searchByThemes: function() {
        if (this.selectedThemes.length === 0) {
            alert('Please select at least one theme.');
            return;
        }
        
        // Navigate to the book list with the theme filters
        const themeQuery = this.selectedThemes
            .map(theme => `theme=${theme}`)
            .join('&');
        
        window.location.hash = `books?${themeQuery}`;
    }
};
