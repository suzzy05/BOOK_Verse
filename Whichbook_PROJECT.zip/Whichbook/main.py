import logging
from app import app, db  # noqa: F401

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Load data from CSV files when in a Flask context
with app.app_context():
    from models import Book
    from csv_loader import load_all_books
    
    # Drop all tables and recreate them
    logger.info("Dropping all tables to apply schema changes...")
    db.drop_all()
    logger.info("Creating all tables with updated schema...")
    db.create_all()
    
    # Load books from CSV files
    logger.info("Loading books from CSV files...")
    load_all_books()
    logger.info(f"After loading, book count: {Book.query.count()}")
    
    # Register API routes
    from routes import register_routes
    register_routes(app)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
