from app import db
import datetime
from sqlalchemy import Column, Integer, String, Float, Text, Table, ForeignKey
from sqlalchemy.orm import relationship

# Association table for many-to-many relationship between books and themes
book_theme = db.Table('book_theme',
    db.Column('book_id', db.Integer, db.ForeignKey('book.id'), primary_key=True),
    db.Column('theme_id', db.Integer, db.ForeignKey('theme.id'), primary_key=True)
)

class Book(db.Model):
    """Book model representing a book in the system"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)  # Increased to handle longer titles
    author = db.Column(db.String(1000), nullable=False)  # Increased to handle longer author lists
    description = db.Column(db.Text, nullable=True)
    isbn = db.Column(db.String(50), nullable=True)  # Increased for longer ISBN formats
    publication_year = db.Column(db.Integer, nullable=True)
    pages = db.Column(db.Integer, nullable=True)
    genre = db.Column(db.String(100), nullable=True)  # Increased for longer genre names
    cover_image = db.Column(db.String(1000), nullable=True)  # Increased for longer URLs
    read_url = db.Column(db.String(1000), nullable=True)  # Increased for longer URLs
    excerpt = db.Column(db.Text, nullable=True)
    average_rating = db.Column(db.Float, default=0.0)
    
    # Mood ratings
    happy_sad = db.Column(db.Integer, default=0)  # -100 (happy) to 100 (sad)
    funny_serious = db.Column(db.Integer, default=0)  # -100 (funny) to 100 (serious)
    safe_disturbing = db.Column(db.Integer, default=0)  # -100 (safe) to 100 (disturbing)
    optimistic_bleak = db.Column(db.Integer, default=0)  # -100 (optimistic) to 100 (bleak)
    conventional_unusual = db.Column(db.Integer, default=0)  # -100 (conventional) to 100 (unusual)
    
    # Relationships
    themes = db.relationship('Theme', secondary=book_theme, lazy='subquery',
                             backref=db.backref('books', lazy=True))
    
    def __repr__(self):
        return f'<Book {self.title} by {self.author}>'

    def to_dict(self):
        """Convert book to dictionary for JSON serialization"""
        # Create mood ratings dictionary
        mood_ratings = {
            "mood_1": self.happy_sad,  # using id as key to match frontend expectations
            "mood_2": self.funny_serious,
            "mood_3": self.safe_disturbing,
            "mood_4": self.optimistic_bleak,
            "mood_5": self.conventional_unusual
        }
        
        # Get theme IDs
        theme_ids = [theme.id for theme in self.themes]
        
        return {
            "id": self.id,
            "title": self.title,
            "author": self.author,
            "description": self.description,
            "isbn": self.isbn,
            "publication_year": self.publication_year,
            "pages": self.pages,
            "genre": self.genre,
            "cover_image": self.cover_image,
            "read_url": self.read_url,
            "excerpt": self.excerpt,
            "average_rating": self.average_rating,
            "mood_ratings": mood_ratings,
            "themes": theme_ids
        }


class Mood(db.Model):
    """Mood model representing a mood/attribute that can be associated with books"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # Increased for longer mood names
    description = db.Column(db.Text, nullable=True)
    min_label = db.Column(db.String(100), nullable=False)  # e.g., "happy"
    max_label = db.Column(db.String(100), nullable=False)  # e.g., "sad"
    
    def __repr__(self):
        return f'<Mood {self.name}>'
    
    def to_dict(self):
        """Convert mood to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "min_label": self.min_label,
            "max_label": self.max_label
        }


class Theme(db.Model):
    """Theme model representing a theme that can be associated with books"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)  # Increased for longer theme names
    description = db.Column(db.Text, nullable=True)
    category = db.Column(db.String(100), nullable=False, default="General")  # Increased for longer category names
    
    def __repr__(self):
        return f'<Theme {self.name}>'
    
    def to_dict(self):
        """Convert theme to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "category": self.category
        }
