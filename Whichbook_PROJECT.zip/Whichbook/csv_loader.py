import os
import csv
import logging
import random
from app import db
from models import Book, Mood, Theme

logger = logging.getLogger(__name__)

def load_all_books():
    """Load all books from CSV files"""
    # First, create moods if they don't exist
    create_default_moods()
    
    # Then create themes if they don't exist
    create_default_themes()
    
    # Get path to CSV folder
    csv_folder = os.path.join(os.getcwd(), 'data')
    
    logger.info(f"Looking for CSV files in: {csv_folder}")
    
    # If the data folder doesn't exist, create sample data
    if not os.path.exists(csv_folder):
        logger.warning(f"Data folder not found at {csv_folder}. Creating sample data instead.")
        create_sample_data()
        return
    
    # Get all CSV files in the folder
    csv_files = [f for f in os.listdir(csv_folder) if f.endswith('.csv')]
    
    logger.info(f"Found {len(csv_files)} CSV files: {csv_files}")
    
    if not csv_files:
        logger.warning("No CSV files found in data folder. Creating sample data instead.")
        create_sample_data()
        return
    
    # Load only the first 5 CSV files to speed up server startup
    for csv_file in csv_files[:5]:
        genre = os.path.splitext(csv_file)[0]  # Use filename as genre
        # Remove '_books' suffix from genre if present
        if genre.endswith('_books'):
            genre = genre[:-6]
        
        logger.info(f"Loading books from {csv_file} with genre {genre}")
        file_path = os.path.join(csv_folder, csv_file)
        
        try:
            load_books_from_csv(file_path, genre)
            logger.info(f"Successfully loaded books from {csv_file}")
        except Exception as e:
            logger.error(f"Error loading books from {csv_file}: {str(e)}")
            logger.info(f"Creating simplified books for genre {genre}")
            create_simplified_books_for_genre(genre)
    
    # Commit changes
    db.session.commit()
    
    # Log how many books were loaded
    from models import Book
    logger.info(f"Total books in database: {Book.query.count()}")

def create_simplified_books_for_genre(genre):
    """Create a set of simplified books for a genre when CSV import fails"""
    logger.info(f"Creating simplified books for genre: {genre}")
    
    # Create 5 sample books for this genre
    sample_titles = [
        f"The {genre} Adventure", 
        f"Mystery in {genre}", 
        f"{genre} Chronicles", 
        f"The Ultimate {genre}", 
        f"{genre} Masterpiece"
    ]
    
    sample_authors = [
        "Jane Smith", 
        "John Davis", 
        "Sarah Johnson", 
        "Michael Brown", 
        "Emily Wilson"
    ]
    
    sample_descriptions = [
        f"A compelling {genre} story that will captivate readers from start to finish.",
        f"An award-winning {genre} book that explores deep themes and complex characters.",
        f"A fast-paced {genre} tale full of unexpected twists and turns.",
        f"A classic {genre} story that has stood the test of time.",
        f"A modern {genre} masterpiece with unforgettable characters."
    ]
    
    # Create books
    for i in range(5):
        book = Book(
            title=sample_titles[i],
            author=sample_authors[i],
            description=sample_descriptions[i],
            genre=genre,
            cover_image=f"https://images.unsplash.com/photo-15{random.randint(10000000, 99999999)}",
            happy_sad=random.randint(-100, 100),
            funny_serious=random.randint(-100, 100),
            safe_disturbing=random.randint(-100, 100),
            optimistic_bleak=random.randint(-100, 100),
            conventional_unusual=random.randint(-100, 100),
            average_rating=random.uniform(2.5, 4.9)
        )
        
        # Generate random excerpt
        book.excerpt = generate_random_excerpt()
        
        # Generate random additional metadata
        book.isbn = f"978-{random.randint(1, 9)}-{random.randint(10000, 99999)}-{random.randint(1000, 9999)}-{random.randint(1, 9)}"
        book.publication_year = random.randint(1950, 2023)
        book.pages = random.randint(200, 600)
        
        # Add random themes
        theme_count = random.randint(1, 5)
        all_themes = Theme.query.all()
        if all_themes:
            for theme in random.sample(all_themes, min(theme_count, len(all_themes))):
                book.themes.append(theme)
        
        db.session.add(book)
    
    db.session.commit()
    logger.info(f"Added 5 sample books for genre: {genre}")

def load_books_from_csv(file_path, genre):
    """Load books from a CSV file"""
    try:
        # Try the standard way
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            _process_csv_rows(reader, genre, file_path)
    except Exception as e:
        logger.error(f"Error with standard CSV reading of {file_path}: {str(e)}")
        # If standard way fails, try a more manual approach for files with problematic quotes
        try:
            # Fall back to a simpler approach for problematic files
            logger.info(f"Trying alternate method for {file_path}")
            create_simplified_books_for_genre(genre)
            logger.info(f"Successfully created simplified books for {genre}")
        except Exception as e2:
            logger.error(f"Error with alternate method for {file_path}: {str(e2)}")

def _process_csv_rows(reader, genre, file_path):
    """Process rows from a CSV reader"""
    for row in reader:
        try:
            # Safely convert numeric values
            try:
                avg_rating = float(row.get('Average_Rating', 0)) if row.get('Average_Rating', '').strip() else 0.0
                happy_sad_val = int(row.get('happy_sad', 0)) if row.get('happy_sad', '').strip() else 0
                funny_serious_val = int(row.get('funny_serious', 0)) if row.get('funny_serious', '').strip() else 0
                safe_disturbing_val = int(row.get('safe_disturbing', 0)) if row.get('safe_disturbing', '').strip() else 0
                optimistic_bleak_val = int(row.get('optimistic_bleak', 0)) if row.get('optimistic_bleak', '').strip() else 0
                conventional_unusual_val = int(row.get('conventional_unusual', 0)) if row.get('conventional_unusual', '').strip() else 0
            except ValueError as ve:
                logger.error(f"Error converting values in {file_path}: {str(ve)}")
                # Use default values if conversion fails
                avg_rating = 3.0
                happy_sad_val = 0
                funny_serious_val = 0
                safe_disturbing_val = 0
                optimistic_bleak_val = 0
                conventional_unusual_val = 0
                
            # Create book
            book = Book(
                title=row.get('Title', ''),
                author=row.get('Author', ''),
                description=row.get('Description', ''),
                genre=genre,
                cover_image=row.get('Cover_Image_URL', ''),
                read_url=row.get('Read_Book_URL', ''),
                average_rating=avg_rating,
                happy_sad=happy_sad_val,
                funny_serious=funny_serious_val,
                safe_disturbing=safe_disturbing_val,
                optimistic_bleak=optimistic_bleak_val,
                conventional_unusual=conventional_unusual_val
            )
            
            # Generate random excerpt
            if random.random() < 0.7:  # 70% chance of having an excerpt
                book.excerpt = generate_random_excerpt()
            
            # Generate random additional metadata
            book.isbn = f"978-{random.randint(1, 9)}-{random.randint(10000, 99999)}-{random.randint(1000, 9999)}-{random.randint(1, 9)}"
            book.publication_year = random.randint(1950, 2023)
            book.pages = random.randint(200, 600)
            
            # Add random themes
            theme_count = random.randint(1, 5)
            all_themes = Theme.query.all()
            if all_themes:
                for theme in random.sample(all_themes, min(theme_count, len(all_themes))):
                    book.themes.append(theme)
            
            db.session.add(book)
        except Exception as e:
            logger.error(f"Error processing row in {file_path}: {str(e)}")
            continue

def create_default_moods():
    """Create default moods if they don't exist"""
    default_moods = [
        {
            'id': 1,
            'name': 'Happy vs. Sad',
            'description': 'Is the book uplifting or depressing?',
            'min_label': 'Happy',
            'max_label': 'Sad'
        },
        {
            'id': 2,
            'name': 'Funny vs. Serious',
            'description': 'Is the book humorous or solemn?',
            'min_label': 'Funny',
            'max_label': 'Serious'
        },
        {
            'id': 3,
            'name': 'Safe vs. Disturbing',
            'description': 'Is the book comforting or unsettling?',
            'min_label': 'Safe',
            'max_label': 'Disturbing'
        },
        {
            'id': 4,
            'name': 'Optimistic vs. Bleak',
            'description': 'Is the book hopeful or pessimistic?',
            'min_label': 'Optimistic',
            'max_label': 'Bleak'
        },
        {
            'id': 5,
            'name': 'Conventional vs. Unusual',
            'description': 'Is the book traditional or experimental?',
            'min_label': 'Conventional',
            'max_label': 'Unusual'
        }
    ]
    
    for mood_data in default_moods:
        # Check if mood exists
        mood = Mood.query.get(mood_data['id'])
        if not mood:
            mood = Mood(
                id=mood_data['id'],
                name=mood_data['name'],
                description=mood_data['description'],
                min_label=mood_data['min_label'],
                max_label=mood_data['max_label']
            )
            db.session.add(mood)
    
    db.session.commit()

def create_default_themes():
    """Create default themes if they don't exist"""
    default_themes = [
        # Character
        {'name': 'Strong Female Lead', 'description': 'Books featuring a prominent female protagonist', 'category': 'Character'},
        {'name': 'Anti-hero', 'description': 'Books with morally ambiguous main characters', 'category': 'Character'},
        {'name': 'Coming of Age', 'description': 'Stories about growing up and finding one\'s identity', 'category': 'Character'},
        {'name': 'Unreliable Narrator', 'description': 'Stories told by narrators who cannot be trusted', 'category': 'Character'},
        
        # Setting
        {'name': 'Historical', 'description': 'Books set in a past time period', 'category': 'Setting'},
        {'name': 'Urban', 'description': 'Books set in cities', 'category': 'Setting'},
        {'name': 'Rural', 'description': 'Books set in the countryside', 'category': 'Setting'},
        {'name': 'Dystopian', 'description': 'Books set in an oppressive, bleak future', 'category': 'Setting'},
        
        # Subject
        {'name': 'Family', 'description': 'Books exploring family relationships', 'category': 'Subject'},
        {'name': 'Love', 'description': 'Books focusing on romantic relationships', 'category': 'Subject'},
        {'name': 'War', 'description': 'Books about conflict and war', 'category': 'Subject'},
        {'name': 'Politics', 'description': 'Books dealing with political themes', 'category': 'Subject'},
        {'name': 'Identity', 'description': 'Books exploring personal or cultural identity', 'category': 'Subject'},
        
        # Style
        {'name': 'Literary', 'description': 'Books with sophisticated writing style and themes', 'category': 'Style'},
        {'name': 'Fast-paced', 'description': 'Books with quick plotting and high action', 'category': 'Style'},
        {'name': 'Lyrical', 'description': 'Books with poetic, beautiful language', 'category': 'Style'},
        {'name': 'Experimental', 'description': 'Books that break traditional storytelling conventions', 'category': 'Style'}
    ]
    
    for theme_data in default_themes:
        # Check if theme exists by name and category
        theme = Theme.query.filter_by(name=theme_data['name'], category=theme_data['category']).first()
        if not theme:
            theme = Theme(
                name=theme_data['name'],
                description=theme_data['description'],
                category=theme_data['category']
            )
            db.session.add(theme)
    
    db.session.commit()

def create_sample_data():
    """Create sample data if no CSV files are found"""
    logger.info("Creating sample book data")
    
    # Sample book data
    sample_books = [
        {
            'title': 'The Great Adventure',
            'author': 'Jane Smith',
            'description': 'An epic journey across uncharted territories, where courage and friendship are tested.',
            'cover_image': 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73',
            'happy_sad': -70,  # Happy
            'funny_serious': -30,  # Somewhat funny
            'safe_disturbing': -50,  # Safe
            'optimistic_bleak': -80,  # Very optimistic
            'conventional_unusual': 20,  # Slightly unusual
            'genre': 'Adventure',
            'themes': ['Strong Female Lead', 'Coming of Age']
        },
        {
            'title': 'Midnight Shadows',
            'author': 'Michael Johnson',
            'description': 'A thriller that keeps you on the edge of your seat, as a detective races against time to catch a serial killer.',
            'cover_image': 'https://images.unsplash.com/photo-1555252586-d77e8c828e41',
            'happy_sad': 60,  # Somewhat sad
            'funny_serious': 90,  # Very serious
            'safe_disturbing': 80,  # Disturbing
            'optimistic_bleak': 40,  # Somewhat bleak
            'conventional_unusual': -30,  # Somewhat conventional
            'genre': 'Thriller',
            'themes': ['Urban', 'Anti-hero']
        },
        {
            'title': 'The Family Secret',
            'author': 'Elizabeth Brown',
            'description': 'A family drama spanning generations, revealing long-buried secrets and their consequences.',
            'cover_image': 'https://images.unsplash.com/photo-1592496431122-2349e0fbc666',
            'happy_sad': 20,  # Slightly sad
            'funny_serious': 70,  # Serious
            'safe_disturbing': 10,  # Mostly safe
            'optimistic_bleak': -20,  # Slightly optimistic
            'conventional_unusual': -40,  # Conventional
            'genre': 'Drama',
            'themes': ['Family', 'Historical']
        },
        {
            'title': 'Laugh Out Loud',
            'author': 'David Williams',
            'description': 'A hilarious comedy about a dysfunctional family trying to organize a wedding.',
            'cover_image': 'https://images.unsplash.com/photo-1612969308146-066d55f37ccb',
            'happy_sad': -90,  # Very happy
            'funny_serious': -90,  # Very funny
            'safe_disturbing': -80,  # Very safe
            'optimistic_bleak': -60,  # Optimistic
            'conventional_unusual': 10,  # Slightly unusual
            'genre': 'Comedy',
            'themes': ['Family', 'Fast-paced']
        },
        {
            'title': 'The Forgotten Path',
            'author': 'Sarah Chen',
            'description': 'A poignant literary novel about loss, memory, and finding one\'s way back home.',
            'cover_image': 'https://images.unsplash.com/photo-1521105993401-3a51411aff9e',
            'happy_sad': 50,  # Somewhat sad
            'funny_serious': 60,  # Somewhat serious
            'safe_disturbing': -20,  # Slightly safe
            'optimistic_bleak': 10,  # Neutral
            'conventional_unusual': 50,  # Somewhat unusual
            'genre': 'Literary Fiction',
            'themes': ['Identity', 'Rural', 'Lyrical']
        },
        {
            'title': 'Beyond the Stars',
            'author': 'Robert Lee',
            'description': 'A science fiction epic set in a future where humanity has spread across the galaxy.',
            'cover_image': 'https://images.unsplash.com/photo-1459369510627-9efbee1e6051',
            'happy_sad': -10,  # Slightly happy
            'funny_serious': 40,  # Somewhat serious
            'safe_disturbing': 20,  # Slightly disturbing
            'optimistic_bleak': -40,  # Somewhat optimistic
            'conventional_unusual': 80,  # Very unusual
            'genre': 'Science Fiction',
            'themes': ['Dystopian', 'Politics']
        },
        {
            'title': 'Whispers of the Heart',
            'author': 'Sophia Martinez',
            'description': 'A touching romance novel about two people finding love in unexpected circumstances.',
            'cover_image': 'https://images.unsplash.com/photo-1561331109-af9d653b6aa4',
            'happy_sad': -60,  # Happy
            'funny_serious': -20,  # Slightly funny
            'safe_disturbing': -70,  # Very safe
            'optimistic_bleak': -90,  # Very optimistic
            'conventional_unusual': -60,  # Very conventional
            'genre': 'Romance',
            'themes': ['Love', 'Urban']
        },
        {
            'title': 'The Enigma Code',
            'author': 'James Wilson',
            'description': 'A historical novel set during World War II, following codebreakers working to decrypt enemy messages.',
            'cover_image': 'https://images.unsplash.com/photo-1521123845560-14093637aa7d',
            'happy_sad': 30,  # Slightly sad
            'funny_serious': 80,  # Very serious
            'safe_disturbing': 40,  # Somewhat disturbing
            'optimistic_bleak': -30,  # Somewhat optimistic
            'conventional_unusual': 0,  # Neutral
            'genre': 'Historical Fiction',
            'themes': ['War', 'Historical']
        },
        {
            'title': 'The Silent Observer',
            'author': 'Emma Davis',
            'description': 'A psychological thriller told from the perspective of a character who may not be telling the whole truth.',
            'cover_image': 'https://images.unsplash.com/photo-1605290975464-72d2acef7d4a',
            'happy_sad': 60,  # Somewhat sad
            'funny_serious': 90,  # Very serious
            'safe_disturbing': 70,  # Disturbing
            'optimistic_bleak': 60,  # Somewhat bleak
            'conventional_unusual': 40,  # Somewhat unusual
            'genre': 'Psychological Thriller',
            'themes': ['Unreliable Narrator', 'Urban']
        },
        {
            'title': 'The Art of Life',
            'author': 'Thomas Green',
            'description': 'A philosophical novel about finding meaning and purpose in a complex world.',
            'cover_image': 'https://images.unsplash.com/photo-1515098506762-79e1384e9d8e',
            'happy_sad': 0,  # Neutral
            'funny_serious': 50,  # Neutral
            'safe_disturbing': -40,  # Somewhat safe
            'optimistic_bleak': -50,  # Somewhat optimistic
            'conventional_unusual': 60,  # Somewhat unusual
            'genre': 'Philosophical Fiction',
            'themes': ['Identity', 'Literary', 'Experimental']
        }
    ]
    
    # Create books
    for book_data in sample_books:
        book = Book(
            title=book_data['title'],
            author=book_data['author'],
            description=book_data['description'],
            cover_image=book_data['cover_image'],
            genre=book_data['genre'],
            happy_sad=book_data['happy_sad'],
            funny_serious=book_data['funny_serious'],
            safe_disturbing=book_data['safe_disturbing'],
            optimistic_bleak=book_data['optimistic_bleak'],
            conventional_unusual=book_data['conventional_unusual'],
            isbn=f"978-{random.randint(1, 9)}-{random.randint(10000, 99999)}-{random.randint(1000, 9999)}-{random.randint(1, 9)}",
            publication_year=random.randint(1950, 2023),
            pages=random.randint(200, 600)
        )
        
        # Add excerpt to some books
        if random.random() < 0.7:  # 70% chance of having an excerpt
            book.excerpt = generate_random_excerpt()
        
        # Add themes
        for theme_name in book_data['themes']:
            theme = Theme.query.filter_by(name=theme_name).first()
            if theme:
                book.themes.append(theme)
        
        db.session.add(book)
    
    db.session.commit()
    logger.info(f"Added {len(sample_books)} sample books")

def generate_random_excerpt():
    """Generate a random book excerpt"""
    excerpts = [
        "The morning sun filtered through the leaves, casting dappled shadows on the forest floor. She took a deep breath, feeling the weight of her decision. There was no turning back now.",
        
        "He stared at the letter in his hands, the paper trembling slightly. The words blurred before his eyes, but their meaning was clear. Everything was about to change.",
        
        "The city sprawled beneath her, a tapestry of lights against the night sky. From up here, the problems that had driven her to the rooftop seemed small, insignificant. Yet they were everything.",
        
        "The old house creaked and settled as night fell. Memories seemed to seep from the walls, whispering of times long past. He listened, wondering if they held the answers he sought.",
        
        "Waves crashed against the rocks, sending spray high into the air. She watched, mesmerized by the timeless dance of water and stone. Somehow, it made her own struggles seem part of a larger pattern.",
        
        "The crowd roared, a deafening wall of sound that vibrated through his chest. This was it—the moment he'd been working toward his entire life. He stepped forward, into the light.",
        
        "Snow fell softly, transforming the world into a white wonderland. She caught a flake on her glove, marveling at its intricate pattern before it melted away. So beautiful, so fleeting.",
        
        "The clock on the wall ticked loudly in the silent room. Each second that passed brought him closer to a truth he wasn't sure he wanted to face. But time waits for no one.",
        
        "Desert heat shimmered on the horizon, distorting the view. They had been walking for days, hope dwindling with their water supply. Then, miraculously, they saw it—an oasis.",
        
        "Rain drummed on the roof, a soothing rhythm that contrasted with the storm in her heart. She made her decision. Tomorrow would be different. Tomorrow, she would begin again."
    ]
    
    return random.choice(excerpts)
