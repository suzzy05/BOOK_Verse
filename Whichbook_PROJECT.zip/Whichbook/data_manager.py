from models import Book, Mood, Theme
from app import db
from sqlalchemy import func, or_, and_
import random
import logging

logger = logging.getLogger(__name__)

class DataManager:
    """Data manager for handling database operations"""
    
    def get_books(self, page=1, per_page=20, mood_filters=None, theme_ids=None):
        """
        Get books with optional filters
        
        Args:
            page (int): Page number
            per_page (int): Items per page
            mood_filters (dict): Dictionary of mood_id -> value for filtering
            theme_ids (list): List of theme IDs to filter by
            
        Returns:
            tuple: (list of books, total count)
        """
        # Start with base query
        query = Book.query
        
        # Apply mood filters if provided
        if mood_filters and isinstance(mood_filters, dict):
            for mood_id, value in mood_filters.items():
                try:
                    # Map mood_id to book attribute
                    mood_map = {
                        "1": Book.happy_sad,
                        "2": Book.funny_serious,
                        "3": Book.safe_disturbing,
                        "4": Book.optimistic_bleak,
                        "5": Book.conventional_unusual
                    }
                    
                    if mood_id in mood_map:
                        # Determine filter based on value direction
                        attribute = mood_map[mood_id]
                        if int(value) < 0:
                            # Negative value (left side of slider)
                            # Find books with values less than or equal to this
                            query = query.filter(attribute <= int(value))
                        elif int(value) > 0:
                            # Positive value (right side of slider)
                            # Find books with values greater than or equal to this
                            query = query.filter(attribute >= int(value))
                except (ValueError, KeyError) as e:
                    logger.warning(f"Invalid mood filter: {mood_id}={value}. Error: {e}")
                    continue
        
        # Apply theme filters if provided
        if theme_ids and isinstance(theme_ids, list):
            # For each theme, join with the book_theme table and filter
            for theme_id in theme_ids:
                # Subquery to find books with this theme
                theme_books = db.session.query(Book.id).join(
                    Book.themes
                ).filter(Theme.id == theme_id).subquery()
                
                # Add to main query
                query = query.filter(Book.id.in_(theme_books))
        
        # Count total before pagination
        total = query.count()
        
        # Apply pagination
        books = query.order_by(Book.id).paginate(page=page, per_page=per_page, error_out=False).items
        
        return books, total
    
    def get_book(self, book_id):
        """Get a single book by ID"""
        return Book.query.get(book_id)
    
    def search_books(self, query_text, page=1, per_page=20):
        """
        Search books by query text
        
        Args:
            query_text (str): Search query
            page (int): Page number
            per_page (int): Items per page
            
        Returns:
            tuple: (list of books, total count)
        """
        if not query_text or not query_text.strip():
            # Return empty results for empty queries
            return [], 0
        
        # Create search query
        search_term = f"%{query_text.lower()}%"
        query = Book.query.filter(
            or_(
                func.lower(Book.title).like(search_term),
                func.lower(Book.author).like(search_term),
                func.lower(Book.description).like(search_term)
            )
        )
        
        # Count total before pagination
        total = query.count()
        
        # Apply pagination
        books = query.order_by(Book.title).paginate(page=page, per_page=per_page, error_out=False).items
        
        return books, total
    
    def get_random_book(self):
        """Get a random book"""
        # Count total books
        total = Book.query.count()
        
        if total == 0:
            return None
        
        # Get a random offset
        random_offset = random.randint(0, total - 1)
        
        # Get the book at that offset
        return Book.query.offset(random_offset).first()
    
    def get_similar_books(self, book_id, count=4):
        """
        Get books similar to the given book based on mood ratings and themes
        
        Args:
            book_id (int): Book ID
            count (int): Number of similar books to return
            
        Returns:
            list: List of similar books
        """
        book = self.get_book(book_id)
        
        if not book:
            return []
        
        # Get books with similar moods
        query = Book.query.filter(Book.id != book_id)
        
        # Calculate mood similarity using a weighted average of the differences
        # between each mood attribute
        mood_query = query.order_by(
            (
                (func.abs(Book.happy_sad - book.happy_sad) +
                 func.abs(Book.funny_serious - book.funny_serious) +
                 func.abs(Book.safe_disturbing - book.safe_disturbing) +
                 func.abs(Book.optimistic_bleak - book.optimistic_bleak) +
                 func.abs(Book.conventional_unusual - book.conventional_unusual))
            ).asc()
        )
        
        # Get book theme IDs
        book_theme_ids = [theme.id for theme in book.themes]
        
        # If book has themes, prioritize books with matching themes
        if book_theme_ids:
            # Count common themes for each book
            # This is a more complex query, so we'll handle it in memory
            # Get books with at least one matching theme
            books_with_matching_themes = []
            
            for similar_book in mood_query.limit(count * 3):  # Get more than needed to allow filtering
                # Count common themes
                similar_book_theme_ids = [theme.id for theme in similar_book.themes]
                common_themes = set(book_theme_ids).intersection(set(similar_book_theme_ids))
                
                books_with_matching_themes.append((similar_book, len(common_themes)))
            
            # Sort by number of common themes (descending), then by mood similarity
            books_with_matching_themes.sort(key=lambda x: x[1], reverse=True)
            
            # Return top books
            similar_books = [book for book, _ in books_with_matching_themes[:count]]
            
            # If we don't have enough books with matching themes, add more based on mood
            if len(similar_books) < count:
                # Get IDs of books we already have
                existing_ids = [b.id for b in similar_books]
                
                # Get more books based on mood similarity, excluding those we already have
                more_books = mood_query.filter(~Book.id.in_(existing_ids)).limit(count - len(similar_books)).all()
                
                similar_books.extend(more_books)
            
            return similar_books
        else:
            # If book has no themes, just return the most similar books by mood
            return mood_query.limit(count).all()
    
    def get_moods(self):
        """Get all available moods"""
        return Mood.query.all()
    
    def get_themes(self):
        """Get all available themes"""
        return Theme.query.order_by(Theme.category, Theme.name).all()
    
    def get_theme_categories(self):
        """Get all theme categories"""
        # Get distinct categories
        categories = db.session.query(Theme.category).distinct().order_by(Theme.category).all()
        
        # Extract category names from result tuples
        return [category[0] for category in categories]
